<?php
// editar_articulo.php
session_start();
require_once 'conexion.php';
$conn->set_charset('utf8');

// Verificar sesión y ID
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die('ID de artículo no especificado o inválido.');
}
$id = intval($_GET['id']);

// Cargar datos en arrays para selects desde la BD
$marcas = $users = $ubicaciones = $clasificaciones = [];
// Marcas
if ($res = $conn->query("SELECT idMarca, nombre FROM marcas")) {
    while ($r = $res->fetch_assoc()) {
        $marcas[] = ['id' => $r['idMarca'], 'name' => $r['nombre']];
    }
    $res->free();
}
// Usuarios (resguardantes)
if ($res = $conn->query("SELECT ID, nombreCompleto FROM users")) {
    while ($r = $res->fetch_assoc()) {
        $users[] = ['id' => $r['ID'], 'name' => $r['nombreCompleto']];
    }
    $res->free();
}
// Ubicaciones
if ($res = $conn->query("SELECT idUbicacion, nombre FROM ubicaciones")) {
    while ($r = $res->fetch_assoc()) {
        $ubicaciones[] = ['id' => $r['idUbicacion'], 'name' => $r['nombre']];
    }
    $res->free();
}
// Clasificaciones
if ($res = $conn->query("SELECT DISTINCT clasificacion FROM articulos")) {
    while ($r = $res->fetch_assoc()) {
        $clasificaciones[] = $r['clasificacion'];
    }
    $res->free();
}

// Obtener datos actuales del artículo
$stmt = $conn->prepare("SELECT * FROM articulos WHERE idArticulo = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    die('Artículo no encontrado.');
}
$articulo = $result->fetch_assoc();
$stmt->close();

// Mensajes para el toast
$mensaje = '';
$tipoMensaje = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recoger y limpiar campos
    $nombre       = trim($_POST['nombre'] ?? '');
    $idMarca      = trim($_POST['idMarca'] ?? '');
    $modelo       = trim($_POST['modelo'] ?? '');
    $clasificacion= trim($_POST['clasificacion'] ?? '');
    $status       = trim($_POST['status'] ?? '');
    $valor        = trim($_POST['valor'] ?? '');
    $descripcion  = trim($_POST['descripcion'] ?? '');
    $numero_serie = trim($_POST['numero_serie'] ?? '');
    $origen       = trim($_POST['origen'] ?? '');
    $vinculado    = trim($_POST['vinculado'] ?? '');
    $tipo         = trim($_POST['tipo'] ?? '');
    $resguardante = trim($_POST['resguardante'] ?? '');
    $ubicacion    = trim($_POST['ubicacion'] ?? '');
    $faltan = array_filter([
        'nombre'=>$nombre,'idMarca'=>$idMarca,'modelo'=>$modelo,
        'clasificacion'=>$clasificacion,'status'=>$status,'valor'=>$valor,
        'descripcion'=>$descripcion,'numero_serie'=>$numero_serie,
        'origen'=>$origen,'vinculado'=>$vinculado,'tipo'=>$tipo,
        'resguardante'=>$resguardante,'ubicacion'=>$ubicacion
    ], fn($v)=> $v==='');
    if (empty($faltan)) {
        $sql = "UPDATE articulos SET
                    nombre=?, idMarca=?, modelo=?, clasificacion=?,
                    status=?, valor=?, descripcion=?, numero_serie=?,
                    origen=?, vinculado=?, tipo=?, resguardante=?, ubicacion=?
                WHERE idArticulo=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "sisssdsssssiii",
            $nombre,$idMarca,$modelo,$clasificacion,
            $status,$valor,$descripcion,$numero_serie,
            $origen,$vinculado,$tipo,$resguardante,$ubicacion,$id
        );
        if ($stmt->execute()) {
            header('Location: main.php?updated=1');
            exit;
        }
        $mensaje = "Error al actualizar: ".$stmt->error;
        $tipoMensaje = 'danger';
        $stmt->close();
    } else {
        $mensaje = 'Completa todos los campos obligatorios.';
        $tipoMensaje = 'warning';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Editar Artículo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background:#141420;color:#E1E1EF; }
    .modal-dialog{max-width:600px;}
    .modal-content{background:#1F1F2E;border-radius:.75rem;overflow:hidden;}
    .modal-header{background:#29294A;border-bottom:none;padding:1rem 1.5rem;}
    .modal-title{color:#FFF;margin:0 auto;}
    .nav-tabs .nav-link{color:#BBB;padding:.5rem 1rem;}
    .nav-tabs .nav-link.active{color:#FFF;background:#2E2E50;border-color:#2E2E50;}
    .form-control,.form-select,textarea{background:#2B2B3F;color:#EEE;border:1px solid #444;}
    .form-control:focus,.form-select:focus,textarea:focus{box-shadow:none;border-color:#4E8CFF;}
    .invalid-feedback{color:#FF6B6B;}
    .modal-body{padding:1.5rem;}
    .modal-footer{background:#29294A;padding:1rem 1.5rem;border-top:none;}
    .d-flex.gap-2>.btn{margin-right:.5rem;}
  </style>
</head>
<body class="d-flex align-items-center justify-content-center vh-100">
  <!-- Toast -->
  <div class="toast-container position-fixed top-0 end-0 p-3">
    <?php if($mensaje): ?>
      <div class="toast show text-bg-<?= $tipoMensaje ?> align-items-center" role="alert">
        <div class="d-flex">
          <div class="toast-body"><?= htmlspecialchars($mensaje) ?></div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
      </div>
    <?php endif; ?>
  </div>
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form id="formArticulo" method="POST" class="needs-validation" novalidate>
        <div class="modal-header">
          <h5 class="modal-title">Editar Artículo</h5>
          <a href="main.php" class="btn-close btn-close-white"></a>
        </div>
        <div class="modal-body">
          <ul class="nav nav-tabs mb-4 justify-content-center">
            <li class="nav-item"><button class="nav-link active" id="tab1-btn" data-bs-toggle="tab" data-bs-target="#tab1" type="button">Parte 1</button></li>
            <li class="nav-item"><button class="nav-link" id="tab2-btn" data-bs-toggle="tab" data-bs-target="#tab2" type="button">Parte 2</button></li>
          </ul>
          <div class="tab-content">
            <!-- Parte 1 -->
            <div class="tab-pane fade show active" id="tab1">
              <!-- Nombre -->
              <div class="mb-3 row">
                <label for="nombre" class="col-sm-3 col-form-label">Nombre</label>
                <div class="col-sm-9">
                  <input type="text" id="nombre" name="nombre" class="form-control" value="<?= htmlspecialchars($articulo['nombre']) ?>" required>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <!-- Marca -->
              <div class="mb-3 row">
                <label for="idMarca" class="col-sm-3 col-form-label">Marca</label>
                <div class="col-sm-9">
                  <select id="idMarca" name="idMarca" class="form-select" required>
                    <option value="">Elige...</option>
                    <?php foreach($marcas as $m): ?>
                      <option value="<?= $m['id'] ?>" <?= $articulo['idMarca']==$m['id']?'selected':'' ?>><?= htmlspecialchars($m['name']) ?></option> <!-- Cambio: == -->
                    <?php endforeach; ?>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <!-- Modelo -->
              <div class="mb-3 row">
                <label for="modelo" class="col-sm-3 col-form-label">Modelo</label>
                <div class="col-sm-9">
                  <input type="text" id="modelo" name="modelo" class="form-control" value="<?= htmlspecialchars($articulo['modelo']) ?>" required>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <!-- Clasificación -->
              <div class="mb-3 row">
                <label for="clasificacion" class="col-sm-3 col-form-label">Clasificación</label>
                <div class="col-sm-9">
                  <input list="clasificacionList" id="clasificacion" name="clasificacion" class="form-control" value="<?= htmlspecialchars($articulo['clasificacion']) ?>" required>
                  <datalist id="clasificacionList">
                    <?php foreach($clasificaciones as $c): ?>
                      <option value="<?= htmlspecialchars($c) ?>"></option>
                    <?php endforeach; ?>
                  </datalist>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <!-- Status -->
              <div class="mb-3 row">
                <label for="status" class="col-sm-3 col-form-label">Status</label>
                <div class="col-sm-9">
                  <select id="status" name="status" class="form-select" required>
                    <option value="">Elige...</option>
                    <?php foreach(['activo','inactivo','en mantenimiento','en prestamo'] as $st): ?>
                      <option value="<?= $st ?>" <?= $articulo['status']===$st?'selected':'' ?>><?= ucfirst($st) ?></option>
                    <?php endforeach; ?>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
            </div>
            <!-- Parte 2 -->
            <div class="tab-pane fade" id="tab2">
              <!-- Valor -->
              <div class="mb-3 row">
                <label for="valor" class="col-sm-3 col-form-label">Valor</label>
                <div class="col-sm-9">
                  <input type="number" step="0.01" id="valor" name="valor" class="form-control" value="<?= htmlspecialchars($articulo['valor']) ?>" required>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <!-- Descripción -->
              <div class="mb-3 row">
                <label for="descripcion" class="col-sm-3 col-form-label">Descripción</label>
                <div class="col-sm-9">
                  <textarea id="descripcion" name="descripcion" rows="3" class="form-control" required><?= htmlspecialchars($articulo['descripcion']) ?></textarea>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <!-- Nº Serie -->
              <div class="mb-3 row">
                <label for="numero_serie" class="col-sm-3 col-form-label">Nº Serie</label>
                <div class="col-sm-9">
                  <input type="text" id="numero_serie" name="numero_serie" class="form-control" value="<?= htmlspecialchars($articulo['numero_serie']) ?>" required>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <!-- Origen -->
              <div class="mb-3 row">
                <label for="origen" class="col-sm-3 col-form-label">Origen</label>
                <div class="col-sm-9">
                  <select id="origen" name="origen" class="form-select" required>
                    <option value="">Elige...</option>
                    <?php foreach(['PATME','SICI','Histórico'] as $o): ?>
                      <option value="<?= $o ?>" <?= $articulo['origen']===$o?'selected':'' ?>><?= $o ?></option>
                    <?php endforeach; ?>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <!-- Vinculado -->
              <div class="mb-3 row">
                <label for="vinculado" class="col-sm-3 col-form-label">Vinculado</label>
                <div class="col-sm-9">
                  <select id="vinculado" name="vinculado" class="form-select" required>
                    <option value="">Elige...</option>
                    <?php foreach(['si','no'] as $v): ?>
                      <option value="<?= $v ?>" <?= $articulo['vinculado']===$v?'selected':'' ?>><?= ucfirst($v) ?></option>
                    <?php endforeach; ?>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <!-- Tipo -->
              <div class="mb-3 row">
                <label for="tipo" class="col-sm-3 col-form-label">Tipo</label>
                <div class="col-sm-9">
                  <select id="tipo" name="tipo" class="form-select" required>
                    <option value="">Elige...</option>
                    <?php foreach(['equipo','mobiliario'] as $t): ?>
                      <option value="<?= $t ?>" <?= $articulo['tipo']===$t?'selected':'' ?>><?= ucfirst($t) ?></option>
                    <?php endforeach; ?>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <!-- Ubicación -->
              <div class="mb-3 row">
                <label for="ubicacion" class="col-sm-3 col-form-label">Ubicación</label>
                <div class="col-sm-9">
                  <select id="ubicacion" name="ubicacion" class="form-select" required>
                    <option value="">Elige...</option>
                    <?php foreach($ubicaciones as $u): ?>
                      <option value="<?= $u['id'] ?>" <?= $articulo['ubicacion']==$u['id']?'selected':'' ?>><?= htmlspecialchars($u['name']) ?></option>
                    <?php endforeach; ?>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <!-- Resguardante -->
              <div class="mb-3 row">
                <label for="resguardante" class="col-sm-3 col-form-label">Resguardante</label>
                <div class="col-sm-9">
                  <select id="resguardante" name="resguardante" class="form-select" required>
                    <option value="">Elige...</option>
                    <?php foreach($users as $ru): ?>
                      <option value="<?= $ru['id'] ?>" <?= $articulo['resguardante']==$ru['id']?'selected':'' ?>><?= htmlspecialchars($ru['name']) ?></option>
                    <?php endforeach; ?>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer d-flex justify-content-between">
          <div class="d-flex gap-2">
            <button type="button" class="btn btn-secondary" id="prevBtn">Anterior</button>
            <button type="button" class="btn btn-primary"   id="nextBtn">Siguiente</button>
          </div>
          <button type="submit" class="btn btn-success" id="submitBtn">Guardar Cambios</button>
        </div>
      </form>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Validación Bootstrap
    (() => {
      const form = document.getElementById('formArticulo');
      form.addEventListener('submit', e => {
        if (!form.checkValidity()) {
          e.preventDefault();
          e.stopPropagation();
        }
        form.classList.add('was-validated');
      });
    })();

    // Navegación entre pestañas
    const tab1Btn=document.getElementById('tab1-btn'),
          tab2Btn=document.getElementById('tab2-btn'),
          prevBtn=document.getElementById('prevBtn'),
          nextBtn=document.getElementById('nextBtn'),
          submitBtn=document.getElementById('submitBtn'),
          t1=new bootstrap.Tab(tab1Btn),
          t2=new bootstrap.Tab(tab2Btn);
    function updateNav(step){
      prevBtn.style.display=step===1?'none':'inline-block';
      nextBtn.style.display=step===2?'none':'inline-block';
      submitBtn.style.display=step===2?'inline-block':'none';
    }
    updateNav(1);
    nextBtn.addEventListener('click',()=>{t2.show();updateNav(2);});
    prevBtn.addEventListener('click',()=>{t1.show();updateNav(1);});
    tab1Btn.addEventListener('shown.bs.tab',()=>updateNav(1));
    tab2Btn.addEventListener('shown.bs.tab',()=>updateNav(2));
  </script>
</body>
</html>
