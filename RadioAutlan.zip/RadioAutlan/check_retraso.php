<?php
require_once 'conexion.php';

if (!isset($_GET['articulos'])) {
    echo json_encode(["success" => false, "message" => "No se proporcionaron artículos."]);
    exit();
}

$articulosStr = $_GET['articulos'];
$articulosArray = explode(',', $articulosStr);
$response = [];
$currentDate = new DateTime();

foreach ($articulosArray as $idArticulo) {
    $idArticulo = trim($idArticulo);
    if(empty($idArticulo)) continue;
    
    // Se consulta la fecha límite del préstamo (último préstamo) para el artículo
    $stmt = $conn->prepare("SELECT fecha_limite_devolucion FROM prestamos WHERE idArticulo = ? ORDER BY idPrestamo DESC LIMIT 1");
    $stmt->bind_param("i", $idArticulo);
    $stmt->execute();
    $result = $stmt->get_result();
    if($row = $result->fetch_assoc()){
        $fechaLimite = new DateTime($row['fecha_limite_devolucion']);
        if($currentDate > $fechaLimite){
            $diff = $currentDate->diff($fechaLimite);
            $diasRetraso = $diff->days;
        } else {
            $diasRetraso = 0;
        }
    } else {
        $diasRetraso = 0;
    }
    $stmt->close();
    $response[] = [
        "idArticulo" => $idArticulo,
        "diasRetraso" => $diasRetraso
    ];
}

echo json_encode(["success" => true, "data" => $response]);
exit();
?>
