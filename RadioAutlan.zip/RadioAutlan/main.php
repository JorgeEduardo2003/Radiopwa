<?php
session_start();
require_once 'conexion.php';
// Verificar que el usuario esté autenticado
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}
// Obtener tipo de usuario desde la sesión
$userType = $_SESSION['tipo'];
// === carga de solicitantes para autocomplete ===
$solicitantes = [];
$rs = $conn->query("SELECT nombreCompleto, codigoInstitucion FROM solicitantes");
while($r = $rs->fetch_assoc()){
    // etiqueta y valor para jQuery UI
    $solicitantes[] = [
        'label' => $r['nombreCompleto'],
        'value' => $r['codigoInstitucion']
    ];
}
// Bloque AJAX para obtener el solicitante desde la BD
if (isset($_GET['action']) && $_GET['action'] == 'obtener_solicitante') {
    $codigo = isset($_GET['codigo']) ? $_GET['codigo'] : '';
    $stmt = $conn->prepare("SELECT idSolicitante, codigoInstitucion, nombreCompleto, cargo FROM solicitantes WHERE codigoInstitucion = ? OR idSolicitante = ?");
    $stmt->bind_param("ss", $codigo, $codigo);
    if(!$stmt->execute()){
        echo json_encode(["success" => false, "message" => "Error en la consulta."]);
        exit();
    }
    $resultSolicitante = $stmt->get_result();
    if ($resultSolicitante->num_rows > 0) {
        $solicitante = $resultSolicitante->fetch_assoc();
        echo json_encode(["success" => true, "data" => $solicitante]);
    } else {
        echo json_encode(["success" => false, "message" => "Solicitante no encontrado."]);
    }
    exit();
}
// Cierre de sesión
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}
// Consulta principal: se obtiene también el nombre del resguardante
$sql = "SELECT a.idArticulo, a.nombre AS articulo, a.modelo, a.valor, a.descripcion, a.clasificacion, 
        a.numero_serie, a.origen, a.status, a.vinculado, a.tipo, 
        m.nombre AS marca, u.nombreCompleto AS resguardante, u2.nombre AS ubicacion
        FROM articulos a 
        JOIN marcas m ON a.idMarca = m.idMarca
        JOIN ubicaciones u2 ON a.ubicacion = u2.idUbicacion
        JOIN users u ON a.resguardante = u.ID";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();
// Consultas para los filtros
$queryStatus = "SELECT DISTINCT status FROM articulos";
$resultStatus = $conn->query($queryStatus);
$queryTipo = "SELECT DISTINCT tipo FROM articulos";
$resultTipo = $conn->query($queryTipo);
$queryOrigen = "SELECT DISTINCT origen FROM articulos";
$resultOrigen = $conn->query($queryOrigen);
$queryClasificacion = "SELECT DISTINCT clasificacion FROM articulos";
$resultClasificacion = $conn->query($queryClasificacion);
$queryMarca = "SELECT DISTINCT m.nombre AS marca FROM articulos a JOIN marcas m ON a.idMarca = m.idMarca";
$resultMarca = $conn->query($queryMarca);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Main - Radio Autlan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- CDNs para html5-qrcode, CryptoJS y jQuery -->
  <script src="https://unpkg.com/html5-qrcode@2.3.6/minified/html5-qrcode.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
  <!-- Se utiliza la librería PHP QR Code (https://phpqrcode.sourceforge.net/) para la generación de QR en otros módulos -->
  <link href="css.css" rel="stylesheet">
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar fixed-top d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center">
      <!-- Botón de menú offcanvas -->
      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu">
        <img src="images/menu_icon.png" alt="Menú" style="width:24px;">
      </button>
      <!-- Logo -->
      <a class="navbar-brand ms-2" href="#">
        <img src="images/logoudg.png" alt="Logo Radio Autlan">
      </a>
    </div>
    <!-- Contenedor del buscador -->
    <div class="search-container">
      <input type="text" id="search" placeholder="Buscar...">
    </div>
    <!-- Controles adicionales: Botón Seleccionar Todo y Escanear QR -->
    <div class="header-controls">
      <button id="btnSelectAll" class="btn-select-all">
        <img src="images/select_all_icon.png" alt="Seleccionar Todo" style="width:20px;"> Seleccionar Todo
      </button>
      <button id="btnQrSearch" class="btn-qr-search">
        <img src="images/qr.png" alt="Escanear QR" style="width:20px;"> Escanear QR
      </button>
    </div>
  </nav>

  <!-- Offcanvas Slide Menu -->
  <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasMenu">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title text-white">Menú</h5>
      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Cerrar"></button>
    </div>
    <div class="offcanvas-body">
      <button class="custom-btn" onclick="generatePdf()">
        <img src="images/pdf_icon.png" alt="PDF" style="width:20px;"> Generar PDF
      </button>
      <button class="custom-btn" data-bs-toggle="modal" data-bs-target="#credencialModal">
        <img src="images/credencial_icon.png" alt="Credencial" style="width:20px;"> Credencial Préstamo
      </button>
      <button class="custom-btn" id="btnAgregarPrestamo">
        <img src="images/agregar_icon.png" alt="Agregar" style="width:20px;"> Agregar Préstamo
      </button>
      <button class="custom-btn" id="btnDevolverPrestamo">
        <img src="images/devolver_icon.png" alt="Devolver" style="width:20px;"> Devolver Préstamo
      </button>
      <button class="custom-btn" onclick="logout()">
        <img src="images/logout_icon.png" alt="Salir" style="width:20px;"> Cerrar Sesión
      </button>
      <?php if($userType == 'admin'): ?>
        <button class="custom-btn" data-bs-toggle="modal" data-bs-target="#addModal">
          <img src="images/add_icon.png" alt="Añadir" style="width:20px;"> Añadir
        </button>
      <?php endif; ?>
    </div>
  </div>

  <!-- Filtros -->
  <div class="container mt-3">
    <div class="row mb-3" id="filters">
      <div class="col-md-2">
        <select id="filter-status" class="form-select">
          <option value="">Todos Status</option>
          <?php while($rowStatus = $resultStatus->fetch_assoc()): ?>
            <option value="<?= $rowStatus['status'] ?>"><?= ucfirst($rowStatus['status']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-2">
        <select id="filter-tipo" class="form-select">
          <option value="">Todos Tipo</option>
          <?php while($rowTipo = $resultTipo->fetch_assoc()): ?>
            <option value="<?= $rowTipo['tipo'] ?>"><?= ucfirst($rowTipo['tipo']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-2">
        <select id="filter-origen" class="form-select">
          <option value="">Todos Origen</option>
          <?php while($rowOrigen = $resultOrigen->fetch_assoc()): ?>
            <option value="<?= $rowOrigen['origen'] ?>"><?= ucfirst($rowOrigen['origen']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-3">
        <select id="filter-clasificacion" class="form-select">
          <option value="">Todas Clasificación</option>
          <?php while($rowClasificacion = $resultClasificacion->fetch_assoc()): ?>
            <option value="<?= $rowClasificacion['clasificacion'] ?>"><?= ucfirst($rowClasificacion['clasificacion']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-3">
        <select id="filter-marca" class="form-select">
          <option value="">Todos Marca</option>
          <?php while($rowMarca = $resultMarca->fetch_assoc()): ?>
            <option value="<?= $rowMarca['marca'] ?>"><?= $rowMarca['marca'] ?></option>
          <?php endwhile; ?>
        </select>
      </div>
    </div>
  </div>

  <!-- Tarjetas -->
  <div class="container mt-4">
    <div class="row" id="card-container">
      <?php while ($row = $result->fetch_assoc()): 
          $status = $row['status'];
          if($status == 'activo'){
              $cardColor = 'var(--bg-card-active)';
          } elseif($status == 'inactivo'){
              $cardColor = 'var(--bg-card-inactivo)';
          } elseif($status == 'en mantenimiento'){
              $cardColor = 'var(--bg-card-maintenance)';
          } elseif($status == 'en prestamo'){
              $cardColor = 'var(--bg-card-loan)';
          } else {
              $cardColor = 'var(--bg-card-default)';
          }
      ?>
        <div class="col-md-4 mb-3">
          <div class="card p-3" style="background-color: <?= $cardColor; ?>;" data-id="<?= $row['idArticulo'] ?>"
            data-articulo="<?= htmlspecialchars($row['articulo']) ?>"
            data-modelo="<?= htmlspecialchars($row['modelo']) ?>"
            data-numero="<?= htmlspecialchars($row['numero_serie']) ?>"
            data-marca="<?= htmlspecialchars($row['marca']) ?>"
            data-valor="<?= htmlspecialchars($row['valor']) ?>"
            data-descripcion="<?= htmlspecialchars($row['descripcion']) ?>"
            data-clasificacion="<?= htmlspecialchars($row['clasificacion']) ?>"
            data-origen="<?= htmlspecialchars($row['origen']) ?>"
            data-status="<?= htmlspecialchars($row['status']) ?>"
            data-vinculado="<?= htmlspecialchars($row['vinculado']) ?>"
            data-tipo="<?= htmlspecialchars($row['tipo']) ?>"
            data-resguardante="<?= htmlspecialchars($row['resguardante']) ?>"
            data-ubicacion="<?= htmlspecialchars($row['ubicacion']) ?>">
            <h5><?= htmlspecialchars($row['articulo']) ?></h5>
            <p><strong>Marca:</strong> <?= htmlspecialchars($row['marca']) ?></p>
            <p><strong>N° Serie:</strong> <?= htmlspecialchars($row['numero_serie']) ?></p>
            <p><strong>Resguardante:</strong> <?= htmlspecialchars($row['resguardante']) ?></p>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>

  <!-- Modal para añadir (solo admin) -->
  <?php if($userType == 'admin'): ?>
  <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content text-light">
        <div class="modal-header">
          <h5 class="modal-title" id="addModalLabel">¿Qué deseas añadir?</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <div class="d-grid gap-2">
            <button type="button" class="custom-btn btn-agregar" onclick="window.location.href='agregar_articulo.php'">
              <img src="images/articulo_icon.png" alt="Artículo" style="width:18px;"> Agregar Artículo
            </button>
            <button type="button" class="custom-btn btn-agregar" onclick="window.location.href='agregar_marca.php'">
              <img src="images/marca_icon.png" alt="Marca" style="width:18px;"> Agregar Marca
            </button>
            <button type="button" class="custom-btn btn-agregar" onclick="window.location.href='agregar_solicitante.php'">
              <img src="images/solicitante_icon.png" alt="Solicitante" style="width:18px;"> Agregar Solicitante
            </button>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="custom-btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- Modal de detalle del artículo -->
  <div class="modal fade" id="detalleModal" tabindex="-1" aria-labelledby="detalleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content text-light">
        <div class="modal-header">
          <h5 class="modal-title" id="detalleModalLabel">Detalle del Artículo</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <table class="modal-table table table-bordered">
            <tbody>
              <tr><th>Artículo</th><td id="modal-articulo"></td></tr>
              <tr><th>Marca</th><td id="modal-marca"></td></tr>
              <tr><th>Número de Serie</th><td id="modal-numero"></td></tr>
              <tr><th>Modelo</th><td id="modal-modelo"></td></tr>
              <tr><th>Valor</th><td id="modal-valor"></td></tr>
              <tr><th>Descripción</th><td id="modal-descripcion"></td></tr>
              <tr><th>Clasificación</th><td id="modal-clasificacion"></td></tr>
              <tr><th>Origen</th><td id="modal-origen"></td></tr>
              <tr><th>Status</th><td id="modal-status"></td></tr>
              <tr><th>Vinculado</th><td id="modal-vinculado"></td></tr>
              <tr><th>Tipo</th><td id="modal-tipo"></td></tr>
              <tr><th>Resguardante</th><td id="modal-resguardante"></td></tr>
              <tr><th>Ubicación</th><td id="modal-ubicacion"></td></tr>
            </tbody>
          </table>
        </div>
        <div class="modal-footer">
          <?php if($userType == 'admin'): ?>
            <button type="button" class="custom-btn btn-editar" id="editar-btn">
              <img src="images/edit_icon.png" alt="Editar" style="width:18px;"> Editar
            </button>
            <button type="button" class="custom-btn btn-eliminar" id="borrar-btn">
              <img src="images/delete_icon.png" alt="Eliminar" style="width:18px;"> Actualizar Estado
            </button>
          <?php endif; ?>
          <button type="button" class="custom-btn btn-generar-etiqueta" id="generar-etiqueta-btn">
            <img src="images/label_icon.png" alt="Etiqueta" style="width:18px;"> Generar etiqueta
          </button>
          <button type="button" class="custom-btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal para Credencial de Préstamo -->
  <div class="modal fade" id="credencialModal" tabindex="-1" aria-labelledby="credencialModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content text-light">
        <div class="modal-header">
          <h5 class="modal-title" id="credencialModalLabel">Buscar Solicitante</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <form id="busquedaForm">
            <div class="mb-3">
              <label for="codigoInput" class="form-label">Código de Solicitante o ID:</label>
              <input type="text" class="form-control" id="codigoInput" placeholder="Ingrese el código o ID">
            </div>
            <button type="submit" class="btn btn-primary">
              <img src="images/search_icon.png" alt="Buscar" style="width:18px;"> Buscar
            </button>
          </form>
          <div id="resultadoBusqueda" class="mt-3"></div>
        </div>
        <div class="modal-footer">
          <button id="btnGenerarPDF" class="btn btn-success" disabled>
            <img src="images/pdf_icon.png" alt="PDF" style="width:18px;"> Generar Credencial PDF
          </button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal para Agregar Préstamo -->
  <div class="modal fade" id="prestamoModal" tabindex="-1" aria-labelledby="prestamoModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content text-light">
        <form id="prestamoForm" action="agregar_prestamo.php" method="POST">
          <div class="modal-header">
            <h5 class="modal-title" id="prestamoModalLabel">Agregar Préstamo</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
          </div>
          <div class="modal-body">
              <div class="mb-3">
                <label for="nombreSolicitante" class="form-label">Nombre del Solicitante:</label>
                <input type="text" class="form-control" id="nombreSolicitante" placeholder="Escribe para buscar..." autocomplete="off">
              </div>
              <div class="mb-3">
                <label for="codigoSolicitante" class="form-label">Código de Solicitante o ID:</label>
                <input type="text" class="form-control" id="codigoSolicitante" name="codigoSolicitante" required>
              </div>
            <!-- Botón para escanear QR en préstamo -->
            <button type="button" id="btnEscanearQR" class="btn btn-warning mb-3">
              <img src="images/qr.png" alt="Escanear" style="width:18px;"> Escanear QR
            </button>
            <div class="mb-3 d-flex justify-content-center ">
              <button type="button" id="btnVerificar" class="btn btn-info px-4 rounded-pill shadow-sm">
                Verificar
              </button>
            </div>
            <div class="mb-3">
              <label for="fechaLimite" class="form-label">Fecha Límite de Devolución:</label>
              <input type="date" class="form-control" id="fechaLimite" name="fechaLimite" required>
            </div>
            <!-- Campo oculto para IDs -->
            <input type="hidden" id="articulosSeleccionados" name="articulos">
          </div>
          <div class="modal-footer">
            <button type="submit" class="custom-btn btn-agregar">
              <img src="images/add_icon.png" alt="Agregar" style="width:18px;"> Agregar Préstamo
            </button>
            <button type="button" class="custom-btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Modal para Escanear QR en Agregar Préstamo (solicitante) -->
  <div class="modal fade" id="qrScanModal" tabindex="-1" aria-labelledby="qrScanModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content text-light">
        <div class="modal-header">
          <h5 class="modal-title" id="qrScanModalLabel">Escanear QR</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar" id="cerrarQR"></button>
        </div>
        <div class="modal-body">
          <div id="qr-reader"></div>
          <div id="qr-reader-error" class="mt-2"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal para Escanear QR de Producto -->
  <div class="modal fade" id="qrProductScanModal" tabindex="-1" aria-labelledby="qrProductScanModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content text-light">
        <div class="modal-header">
          <h5 class="modal-title" id="qrProductScanModalLabel">Escanear QR de Producto</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar" id="cerrarQRProduct"></button>
        </div>
        <div class="modal-body">
          <div id="qr-reader-product"></div>
          <div id="qr-reader-error-product" class="mt-2"></div>
          <div class="mt-3">
            <label for="scannedId" class="form-label">ID Escaneado:</label>
            <input type="text" id="scannedId" class="form-control" readonly>
          </div>
          <button id="btnBuscarProducto" class="btn btn-primary mt-3">
            <img src="images/lupa.png" alt="Buscar" style="width:18px;"> Buscar Producto
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal para Devolver Préstamo -->
  <div class="modal fade" id="devolucionModal" tabindex="-1" aria-labelledby="devolucionModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content text-light">
        <form id="devolucionForm" action="devolver_prestamo.php" method="POST">
          <div class="modal-header">
            <h5 class="modal-title" id="devolucionModalLabel">Marcar Artículos como Devueltos</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" id="articulosDevolver" name="articulos">
            <div id="retrasoInfo"></div>
            <p>¿Confirma que los artículos seleccionados ya fueron devueltos?</p>
          </div>
          <div class="modal-footer">
            <button type="submit" class="custom-btn btn-agregar">
              <img src="images/confirm_icon.png" alt="Confirmar" style="width:18px;"> Marcar como Devueltos
            </button>
            <button type="button" class="custom-btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Librerías Bootstrap Bundle, jsPDF y QRCode -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
  
  <script>
    // Función para cerrar sesión
    function logout() {
      window.location.href = "main.php?logout=true";
    }
    
    // Función para generar PDF (basado en los artículos seleccionados)
    function generatePdf() {
      const selectedItems = JSON.parse(localStorage.getItem('selectedItems') || "[]");
      if(selectedItems.length === 0) {
        alert("No has seleccionado ningún artículo para el reporte.");
        return;
      }
      window.location.href = "generarpdf.php?ids=" + selectedItems.join(',');
    }
    
    // Variable global para almacenar el ID del artículo seleccionado y el lector QR para producto
    let currentArticleId = null;
    let html5QrCodeProduct; // Variable global para el lector de producto
    
    $(document).ready(function () {
      const selectedItems = new Set(JSON.parse(localStorage.getItem('selectedItems') || "[]"));
      function updateStorage() {
        localStorage.setItem('selectedItems', JSON.stringify([...selectedItems]));
      }
      function updateSelection() {
        $(".card").each(function () {
          const id = $(this).data("id");
          $(this).toggleClass("selected", selectedItems.has(id));
        });
      }


      // Seleccionar/deseleccionar tarjeta al hacer clic izquierdo
      $(".card").click(function (e) {
        if(e.which === 1){
          const id = $(this).data("id");
          if (selectedItems.has(id)) {
            selectedItems.delete(id);
          } else {
            selectedItems.add(id);
          }
          updateStorage();
          updateSelection();
        }
      });
      
      // Mostrar detalle con clic derecho sobre la tarjeta
      $(".card").on("contextmenu", function (e) {
        e.preventDefault();
        const $card = $(this);
        currentArticleId = $card.data("id");
        $("#modal-articulo").text($card.data("articulo"));
        $("#modal-marca").text($card.data("marca"));
        $("#modal-modelo").text($card.data("modelo"));
        $("#modal-numero").text($card.data("numero"));
        $("#modal-valor").text($card.data("valor"));
        $("#modal-descripcion").text($card.data("descripcion"));
        $("#modal-clasificacion").text($card.data("clasificacion"));
        $("#modal-origen").text($card.data("origen"));
        $("#modal-status").text($card.data("status"));
        $("#modal-vinculado").text($card.data("vinculado"));
        $("#modal-tipo").text($card.data("tipo"));
        $("#modal-resguardante").text($card.data("resguardante"));
        $("#modal-ubicacion").text($card.data("ubicacion"));
        $("#editar-btn").data("id", $card.data("id"));
        $("#borrar-btn").data("id", $card.data("id"));
        var detalleModal = new bootstrap.Modal(document.getElementById('detalleModal'));
        detalleModal.show();
      });
      
      $("#editar-btn").click(function () {
        var id = $(this).data("id");
        window.location.href = "editar_articulo.php?id=" + id;
      });
      
      $("#borrar-btn").click(function () {
        var id = $(this).data("id");
        window.location.href = "borrar_articulo.php?id=" + id;
      });
      
      // Botón "Seleccionar Todo"
      $("#btnSelectAll").click(function () {
        if (selectedItems.size < $(".card").length) {
          $(".card").each(function () {
            selectedItems.add($(this).data("id"));
          });
        } else {
          selectedItems.clear();
        }
        updateStorage();
        updateSelection();
      });
      
      // Función para filtrar tarjetas según búsqueda y filtros
      function filterCards() {
        const searchText = $("#search").val().toLowerCase();
        const filterStatus = $("#filter-status").val();
        const filterTipo = $("#filter-tipo").val();
        const filterOrigen = $("#filter-origen").val();
        const filterClasificacion = $("#filter-clasificacion").val();
        const filterMarca = $("#filter-marca").val();
        
        $("#card-container .col-md-4").each(function () {
          const $col = $(this);
          const $card = $col.find(".card");
          const cardText = $card.text().toLowerCase();
          const status = $card.data("status");
          const tipo = $card.data("tipo");
          const origen = $card.data("origen");
          const clasificacion = $card.data("clasificacion");
          const marca = $card.data("marca");
          let show = true;
          if (searchText && !cardText.includes(searchText)) {
            show = false;
          }
          if (filterStatus && status !== filterStatus) {
            show = false;
          }
          if (filterTipo && tipo !== filterTipo) {
            show = false;
          }
          if (filterOrigen && origen !== filterOrigen) {
            show = false;
          }
          if (filterClasificacion && clasificacion !== filterClasificacion) {
            show = false;
          }
          if (filterMarca && marca !== filterMarca) {
            show = false;
          }
          $col.toggle(show);
        });
      }
      
      $("#search, #filter-status, #filter-tipo, #filter-origen, #filter-clasificacion, #filter-marca").on("input change", function(){
         filterCards();
      });
      
      updateSelection();
       // === INICIO parche Autocomplete en modal de préstamo ===
        // convierte el array PHP en JS (assigned arriba en tu script)
        const solicitantes = <?= json_encode($solicitantes, JSON_UNESCAPED_UNICODE) ?>;

        $('#prestamoModal').on('shown.bs.modal', function() {
          // 1) Limpiar ambos campos al abrir
          $("#nombreSolicitante, #codigoSolicitante").val('');

          // 2) Inicializar Autocomplete SOLO aquí
          $("#nombreSolicitante").autocomplete({
            source: solicitantes,
            minLength: 1,
            autoFocus: true,
            select: function(event, ui) {
              $("#nombreSolicitante").val(ui.item.label);
              $("#codigoSolicitante").val(ui.item.value);
              return false;
            }
            
          });
          // === BOTÓN VERIFICAR: sincroniza nombre y código sin desactivar nada ===
        $('#btnVerificar').on('click', function() {
          const name = $('#nombreSolicitante').val().trim().toLowerCase();
          const code = $('#codigoSolicitante').val().trim();
          let match;

          // 1) si hay nombre escrito, buscamos correspondencia aproximada
          if (name) {
            match = solicitantes.find(item => item.label.toLowerCase() === name);
            if (match) {
              $('#codigoSolicitante').val(match.value);
              return;
            }
          }

          // 2) si hay código escrito, buscamos el nombre
          if (code) {
            match = solicitantes.find(item => item.value === code);
            if (match) {
              $('#nombreSolicitante').val(match.label);
              return;
            }
          }

          // 3) si nada encontró, aviso al usuario
          alert('No se encontró coincidencia de nombre o código.');
        });


          // 3) Si el usuario edita el campo código, sincronizar el nombre
          $("#codigoSolicitante")
            .off('change.autosync')                   // quitar handlers previos
            .on('change.autosync', function() {
              const code = $(this).val().trim();
              const match = solicitantes.find(item => item.value === code);
              $("#nombreSolicitante").val(match ? match.label : '');
            });
        });
        // === FIN parche Autocomplete en modal de préstamo ===

      // Modal de Credencial de Préstamo
      let selectedSolicitante = null;
      $("#busquedaForm").on("submit", function(e) {
        e.preventDefault();
        const codigoInput = $("#codigoInput").val().trim();
        $.ajax({
          url: "main.php",
          method: "GET",
          data: { action: "obtener_solicitante", codigo: codigoInput },
          dataType: "json",
          success: function(response) {
            if(response.success) {
              selectedSolicitante = response.data;
              $("#resultadoBusqueda").html("<p>Encontrado: " + selectedSolicitante.nombreCompleto + " - Cargo: " + selectedSolicitante.cargo + "</p>");
              $("#btnGenerarPDF").prop("disabled", false);
            } else {
              $("#resultadoBusqueda").html("<p>No se encontró solicitante.</p>");
              $("#btnGenerarPDF").prop("disabled", true);
            }
          },
          error: function() {
            $("#resultadoBusqueda").html("<p>Error en la consulta.</p>");
            $("#btnGenerarPDF").prop("disabled", true);
          }
        });
      });
      
      $("#btnGenerarPDF").on("click", function() {
        if (!selectedSolicitante) return;
        window.open("generarcredencial.php?codigo=" + encodeURIComponent(selectedSolicitante.codigoInstitucion), "_blank");
      });
      
      // Modal de Agregar Préstamo
      $("#btnAgregarPrestamo").click(function(){
          const items = JSON.parse(localStorage.getItem('selectedItems') || "[]");
          if(items.length === 0) {
              alert("No has seleccionado ningún artículo para el préstamo.");
              return;
          }
          $("#articulosSeleccionados").val(items.join(','));
          var prestamoModal = new bootstrap.Modal(document.getElementById('prestamoModal'));
          prestamoModal.show();
      });
      
      // Modal de Devolver Préstamo
      $("#btnDevolverPrestamo").click(function(){
          const items = JSON.parse(localStorage.getItem('selectedItems') || "[]");
          if(items.length === 0) {
              alert("No has seleccionado ningún artículo para la devolución.");
              return;
          }
          $("#articulosDevolver").val(items.join(','));
          $.ajax({
            url: "check_retraso.php",
            method: "GET",
            data: { articulos: items.join(',') },
            dataType: "json",
            success: function(response) {
              let infoHtml = "";
              if(response.success) {
                response.data.forEach(function(item) {
                  if(item.diasRetraso > 0) {
                    infoHtml += "<p>Artículo ID " + item.idArticulo + " - Retraso: " + item.diasRetraso + " día(s)</p>";
                  } else {
                    infoHtml += "<p>Artículo ID " + item.idArticulo + " - Sin retraso</p>";
                  }
                });
              } else {
                infoHtml = "<p>No se pudo determinar el retraso.</p>";
              }
              $("#retrasoInfo").html(infoHtml);
              var devolucionModal = new bootstrap.Modal(document.getElementById('devolucionModal'));
              devolucionModal.show();
            },
            error: function() {
              $("#retrasoInfo").html("<p>Error al consultar retrasos.</p>");
              var devolucionModal = new bootstrap.Modal(document.getElementById('devolucionModal'));
              devolucionModal.show();
            }
          });
      });
      
      // Función para escanear QR en Agregar Préstamo (solicitante)
  $("#btnEscanearQR").click(function(){
    // Mostrar modal de escaneo
    var qrScanModal = new bootstrap.Modal(document.getElementById('qrScanModal'));
    qrScanModal.show();
    
    // Inicializar lector HTML5 QR Code
    const html5QrCode = new Html5Qrcode("qr-reader");
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
  $("#qr-reader-error").text("No hay acceso a cámara.");
  return;
}

    // Obtener cámaras disponibles y usar la primera
    Html5Qrcode.getCameras().then(cameras => {
      if (cameras && cameras.length) {
        const cameraId = cameras[0].id; // Selecciona la primera cámara disponible
        html5QrCode.start(
          cameraId, // Usar ID de cámara
          { fps: 10, qrbox: 250 }, // Configuración de escaneo
          (decodedText, decodedResult) => {
            console.log("QR leído (préstamo):", decodedText);
            // Aquí va tu lógica de descifrado con CryptoJS
            const key = CryptoJS.enc.Utf8.parse("UDG2025");
            let decrypted = CryptoJS.AES.decrypt(decodedText, key, { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 });
            let plainText = decrypted.toString(CryptoJS.enc.Utf8);
            if (plainText) {
              $("#codigoSolicitante").val(plainText);
              html5QrCode.stop().then(() => {
                qrScanModal.hide(); // Ocultar modal al detener el lector
              }).catch(err => {
                $("#qr-reader-error").html("Error al detener el lector: " + err);
              });
            }
          },
          (errorMessage) => {
            $("#qr-reader-error").html("Error de escaneo: " + errorMessage);
          }
        ).catch(err => {
          $("#qr-reader-error").html("Error al iniciar el lector QR: " + err);
        });
      } else {
        $("#qr-reader-error").html("No se encontró ninguna cámara disponible.");
      }
    }).catch(err => {
      $("#qr-reader-error").html("Error al obtener cámaras: " + err);
    });
  });
      
      // Funcionalidad para escanear QR de producto (búsqueda)
    $("#btnQrSearch").click(function(){
      // Mostrar modal de escaneo de producto
      var qrProductModal = new bootstrap.Modal(document.getElementById('qrProductScanModal'));
      qrProductModal.show();
      
      // Inicializar lector HTML5 QR Code para producto
      const html5QrCodeProduct = new Html5Qrcode("qr-reader-product");
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        $("#qr-reader-error").text("Tu navegador no soporta acceso a cámara.");
        return;
      }

      // Obtener cámaras disponibles y usar la primera
      Html5Qrcode.getCameras().then(cameras => {
        if (cameras && cameras.length) {
          const cameraId = cameras[0].id; // Selecciona la primera cámara disponible
          html5QrCodeProduct.start(
            cameraId, // Usar ID de cámara
            { fps: 10, qrbox: 250 }, // Configuración de escaneo
            (decodedText, decodedResult) => {
              console.log("QR leído (producto):", decodedText);
              // Aquí va tu lógica de descifrado con CryptoJS para producto
              const key = CryptoJS.enc.Utf8.parse("raido2025");
              let decrypted = CryptoJS.AES.decrypt(decodedText, key, { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 });
              let plainText = decrypted.toString(CryptoJS.enc.Utf8);
              if (plainText) {
                $("#scannedId").val(plainText);
              }
            },
            (errorMessage) => {
              $("#qr-reader-error-product").html("Error de escaneo: " + errorMessage);
            }
          ).catch(err => {
            $("#qr-reader-error-product").html("Error al iniciar el lector QR: " + err);
          });
        } else {
          $("#qr-reader-error-product").html("No se encontró ninguna cámara disponible.");
        }
      }).catch(err => {
        $("#qr-reader-error-product").html("Error al obtener cámaras: " + err);
      });
  });
      
      // Acción al hacer clic en "Buscar Producto" en el modal de producto
      $("#btnBuscarProducto").click(function(){
          let productId = $("#scannedId").val();
          if(productId === "") {
              alert("No se ha escaneado ningún ID.");
              return;
          }
          let $targetCard = $("#card-container .card").filter(function(){
              return $(this).data("id") == productId;
          });
          if($targetCard.length > 0) {
              $targetCard.addClass("selected");
              currentArticleId = $targetCard.data("id");
              $("#modal-articulo").text($targetCard.data("articulo"));
              $("#modal-marca").text($targetCard.data("marca"));
              $("#modal-modelo").text($targetCard.data("modelo"));
              $("#modal-numero").text($targetCard.data("numero"));
              $("#modal-valor").text($targetCard.data("valor"));
              $("#modal-descripcion").text($targetCard.data("descripcion"));
              $("#modal-clasificacion").text($targetCard.data("clasificacion"));
              $("#modal-origen").text($targetCard.data("origen"));
              $("#modal-status").text($targetCard.data("status"));
              $("#modal-vinculado").text($targetCard.data("vinculado"));
              $("#modal-tipo").text($targetCard.data("tipo"));
              $("#modal-resguardante").text($targetCard.data("resguardante"));
              $("#editar-btn").data("id", $targetCard.data("id"));
              $("#borrar-btn").data("id", $targetCard.data("id"));
              var detalleModal = new bootstrap.Modal(document.getElementById('detalleModal'));
              detalleModal.show();
          } else {
              alert("Producto no encontrado.");
          }
          if(html5QrCodeProduct){
            html5QrCodeProduct.stop().then(() => {
              console.log("Lector QR de producto detenido.");
            }).catch(err => {
              console.error("Error al detener el lector QR:", err);
            });
          }
          $("#qrProductScanModal").modal('hide');
      });
      
      // Botón para generar etiqueta usando currentArticleId
      $("#generar-etiqueta-btn").click(function () {
        if (currentArticleId) {
          window.open("generar_etiqueta.php?id=" + currentArticleId, "_blank");
        } else {
          alert("No se encontró el ID del artículo.");
        }
      });
      
    });
  </script>
</body>
</html>
