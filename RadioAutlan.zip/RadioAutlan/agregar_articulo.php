<?php
// agregar_articulo.php
require_once 'conexion.php';
$conn->set_charset('utf8');

// Cargar datos en arrays para selects
$marcas = $users = $ubicaciones = [];
foreach ([
    'marcas'      => 'idMarca,nombre',
    'users'       => 'ID,nombreCompleto',
    'ubicaciones' => 'idUbicacion,nombre'
] as $tabla => $cols) {
    list($idCol, $nameCol) = explode(',', $cols);
    if ($res = $conn->query("SELECT $idCol, $nameCol FROM $tabla")) {
        while ($r = $res->fetch_row()) {
            ${$tabla}[] = ['id' => $r[0], 'name' => $r[1]];
        }
        $res->free();
    }
}

// Mensajes para el toast
$mensaje = '';
$tipoMensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $campos = [
        'nombre','idMarca','modelo','clasificacion','status',
        'valor','descripcion','numero_serie','origen',
        'vinculado','tipo','resguardante','ubicacion'
    ];
    foreach ($campos as $c) {
        $$c = trim($_POST[$c] ?? '');
    }
    $vacios = array_filter($campos, fn($c) => $$c === '');
    if (empty($vacios)) {
        $sql = "INSERT INTO articulos (" . implode(',', $campos) . ")
                VALUES (" . rtrim(str_repeat('?,', count($campos)), ',') . ")";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param(
                "sisssdsssssii",
                $nombre, $idMarca, $modelo, $clasificacion,
                $status, $valor, $descripcion, $numero_serie,
                $origen, $vinculado, $tipo, $resguardante,
                $ubicacion
            );
            if ($stmt->execute()) {
                header('Location: main.php?success=1');
                exit;
            }
            $mensaje = "Error al insertar: " . $stmt->error;
            $tipoMensaje = 'danger';
            $stmt->close();
        } else {
            $mensaje = "Error al preparar la consulta: " . $conn->error;
            $tipoMensaje = 'danger';
        }
    } else {
        $mensaje = 'Completa todos los campos obligatorios.';
        $tipoMensaje = 'warning';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Agregar Artículo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #141420;
      color: #E1E1EF;
    }
    .modal-dialog {
      max-width: 600px;
    }
    .modal-content {
      background: #1F1F2E;
      border-radius: .75rem;
      overflow: hidden;
    }
    .modal-header {
      background: #29294A;
      border-bottom: none;
      padding: 1rem 1.5rem;
    }
    .modal-title {
      color: #FFF;
      margin: 0 auto;
    }
    .nav-tabs .nav-link {
      color: #BBB;
      padding: .5rem 1rem;
    }
    .nav-tabs .nav-link.active {
      color: #FFF;
      background: #2E2E50;
      border-color: #2E2E50;
    }
    .form-control, .form-select, textarea {
      background: #2B2B3F;
      color: #EEE;
      border: 1px solid #444;
    }
    .form-control:focus,
    .form-select:focus,
    textarea:focus {
      box-shadow: none;
      border-color: #4E8CFF;
    }
    .invalid-feedback {
      color: #FF6B6B;
    }
    .modal-body {
      padding: 1.5rem;
    }
    .modal-footer {
      background: #29294A;
      padding: 1rem 1.5rem;
      border-top: none;
    }
    .d-flex.gap-2 > .btn {
      margin-right: .5rem;
    }
  </style>
</head>
<body class="d-flex align-items-center justify-content-center vh-100">

  <!-- Toast de mensajes -->
  <div class="toast-container position-fixed top-0 end-0 p-3">
    <?php if ($mensaje): ?>
      <div class="toast show text-bg-<?= $tipoMensaje ?> align-items-center" role="alert">
        <div class="d-flex">
          <div class="toast-body"><?= htmlspecialchars($mensaje) ?></div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form id="formArticulo" method="POST" class="needs-validation" novalidate>
        <!-- Header -->
        <div class="modal-header">
          <h5 class="modal-title">Agregar Artículo</h5>
          <a href="main.php" class="btn-close btn-close-white"></a>
        </div>

        <!-- Body -->
        <div class="modal-body">
          <!-- Pestañas -->
          <ul class="nav nav-tabs mb-4 justify-content-center" id="formTab" role="tablist">
            <li class="nav-item">
              <button class="nav-link active" id="tab1-btn" data-bs-toggle="tab" data-bs-target="#tab1" type="button">
                Parte 1
              </button>
            </li>
            <li class="nav-item">
              <button class="nav-link" id="tab2-btn" data-bs-toggle="tab" data-bs-target="#tab2" type="button">
                Parte 2
              </button>
            </li>
          </ul>

          <div class="tab-content">
            <!-- Parte 1 -->
            <div class="tab-pane fade show active" id="tab1">
              <div class="mb-3 row">
                <label for="nombre" class="col-sm-3 col-form-label">Nombre</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" id="nombre" name="nombre" required>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <div class="mb-3 row">
                <label for="idMarca" class="col-sm-3 col-form-label">Marca</label>
                <div class="col-sm-9">
                  <select class="form-select" id="idMarca" name="idMarca" required>
                    <option value="">Elige...</option>
                    <?php foreach ($marcas as $m): ?>
                      <option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['name']) ?></option>
                    <?php endforeach; ?>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <div class="mb-3 row">
                <label for="modelo" class="col-sm-3 col-form-label">Modelo</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" id="modelo" name="modelo" required>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <div class="mb-3 row">
                <label for="clasificacion" class="col-sm-3 col-form-label">Clasificación</label>
                <div class="col-sm-9">
                  <input list="clasificacionList" class="form-control" id="clasificacion" name="clasificacion" required>
                  <datalist id="clasificacionList">
                    <!-- Opciones aquí -->
                  </datalist>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <div class="mb-3 row">
                <label for="status" class="col-sm-3 col-form-label">Status</label>
                <div class="col-sm-9">
                  <select class="form-select" id="status" name="status" required>
                    <option value="">Elige...</option>
                    <option>activo</option>
                    <option>inactivo</option>
                    <option>en mantenimiento</option>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
            </div>

            <!-- Parte 2 -->
            <div class="tab-pane fade" id="tab2">
              <div class="mb-3 row">
                <label for="valor" class="col-sm-3 col-form-label">Valor</label>
                <div class="col-sm-9">
                  <input type="number" step="0.01" class="form-control" id="valor" name="valor" required>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <div class="mb-3 row">
                <label for="descripcion" class="col-sm-3 col-form-label">Descripción</label>
                <div class="col-sm-9">
                  <textarea class="form-control" id="descripcion" name="descripcion" rows="3" required></textarea>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <div class="mb-3 row">
                <label for="numero_serie" class="col-sm-3 col-form-label">Número de Serie</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" id="numero_serie" name="numero_serie" required>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <div class="mb-3 row">
                <label for="origen" class="col-sm-3 col-form-label">Origen</label>
                <div class="col-sm-9">
                  <select class="form-select" id="origen" name="origen" required>
                    <option value="">Elige...</option>
                    <option>PATME</option>
                    <option>SICI</option>
                    <option>Histórico</option>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <div class="mb-3 row">
                <label for="vinculado" class="col-sm-3 col-form-label">Vinculado</label>
                <div class="col-sm-9">
                  <select class="form-select" id="vinculado" name="vinculado" required>
                    <option value="">Elige...</option>
                    <option>si</option>
                    <option>no</option>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <div class="mb-3 row">
                <label for="tipo" class="col-sm-3 col-form-label">Tipo</label>
                <div class="col-sm-9">
                  <select class="form-select" id="tipo" name="tipo" required>
                    <option value="">Elige...</option>
                    <option>equipo</option>
                    <option>mobiliario</option>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <div class="mb-3 row">
                <label for="ubicacion" class="col-sm-3 col-form-label">Ubicación</label>
                <div class="col-sm-9">
                  <select class="form-select" id="ubicacion" name="ubicacion" required>
                    <option value="">Elige...</option>
                    <?php foreach ($ubicaciones as $u): ?>
                      <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?></option>
                    <?php endforeach; ?>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
              <div class="mb-3 row">
                <label for="resguardante" class="col-sm-3 col-form-label">Resguardante</label>
                <div class="col-sm-9">
                  <select class="form-select" id="resguardante" name="resguardante" required>
                    <option value="">Elige...</option>
                    <?php foreach ($users as $ru): ?>
                      <option value="<?= $ru['id'] ?>"><?= htmlspecialchars($ru['name']) ?></option>
                    <?php endforeach; ?>
                  </select>
                  <div class="invalid-feedback">Requerido</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Footer con botones espacados -->
        <div class="modal-footer d-flex justify-content-between">
          <div class="d-flex gap-2">
            <button type="button" class="btn btn-secondary" id="prevBtn">Anterior</button>
            <button type="button" class="btn btn-primary" id="nextBtn">Siguiente</button>
          </div>
          <button type="submit" class="btn btn-success" id="submitBtn">Agregar Artículo</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Validación con Bootstrap
    (()=>{
      const form = document.getElementById('formArticulo');
      form.addEventListener('submit', e => {
        if (!form.checkValidity()) {
          e.preventDefault();
          e.stopPropagation();
        }
        form.classList.add('was-validated');
      });
    })();

    // Navegación entre pestañas
    const tab1Btn   = document.getElementById('tab1-btn'),
          tab2Btn   = document.getElementById('tab2-btn'),
          prevBtn   = document.getElementById('prevBtn'),
          nextBtn   = document.getElementById('nextBtn'),
          submitBtn = document.getElementById('submitBtn'),
          t1        = new bootstrap.Tab(tab1Btn),
          t2        = new bootstrap.Tab(tab2Btn);

    function updateNav(step) {
      prevBtn.style.display   = step === 1 ? 'none' : 'inline-block';
      nextBtn.style.display   = step === 2 ? 'none' : 'inline-block';
      submitBtn.style.display = step === 2 ? 'inline-block' : 'none';
    }
    updateNav(1);

    nextBtn.addEventListener('click', () => { t2.show(); updateNav(2); });
    prevBtn.addEventListener('click', () => { t1.show(); updateNav(1); });
    tab1Btn.addEventListener('shown.bs.tab', () => updateNav(1));
    tab2Btn.addEventListener('shown.bs.tab', () => updateNav(2));
  </script>
</body>
</html>
