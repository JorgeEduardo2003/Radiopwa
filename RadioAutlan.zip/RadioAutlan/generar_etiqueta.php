<?php
require_once 'conexion.php';
require('fpdf.php'); // Asegúrate de tener instalada la librería FPDF

// Verificar que se reciba el parámetro "id" del producto
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("No se proporcionó el ID del producto.");
}

$idProducto = $_GET['id'];

// Consultar la base de datos para obtener los datos del producto
$stmt = $conn->prepare("SELECT nombre, numero_serie FROM articulos WHERE idArticulo = ?");
$stmt->bind_param("s", $idProducto);
$stmt->execute();
$resultProducto = $stmt->get_result();

if ($resultProducto->num_rows === 0) {
    die("Producto no encontrado.");
}

$producto = $resultProducto->fetch_assoc();

// Encriptar el ID del producto con AES-128-ECB y la clave "raido2025"
$clave  = "raido2025";
$metodo = "AES-128-ECB";
$encriptado = openssl_encrypt($idProducto, $metodo, $clave);
$encriptadoUrl = urlencode($encriptado); // Para utilizar en la URL del QR

// Generar la URL del código QR utilizando el ID encriptado
$qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . $encriptadoUrl;

// Intentar descargar la imagen del QR
$qrImage = @file_get_contents($qrUrl);
if($qrImage === false) {
    echo "Error al generar el código QR. Redirigiendo...";
    header("refresh:3; url=main.php");
    exit();
}
$tempQRPath = 'temp_qr.png';
file_put_contents($tempQRPath, $qrImage);

// CONFIGURACIÓN DE LA ETIQUETA
// Se utiliza un tamaño aproximado de 60 x 90 mm
class PDF extends FPDF {
    function Header() {
        // Cabecera vacía o personalizable
    }
    function Footer() {
        $this->SetY(-5);
        $this->SetFont('Arial','I',6);
        $this->Cell(0,3,utf8_decode('Radio Autlan'),0,0,'C');
    }
}

$pdf = new PDF('P', 'mm', [60, 90]);
$pdf->AddPage();

$pageWidth  = $pdf->GetPageWidth();
$pageHeight = $pdf->GetPageHeight();

// 1) LOGO CENTRADO
$logoWidth = 20;  // Ajusta el tamaño del logo según convenga
$logoX = ($pageWidth - $logoWidth) / 2;
$logoY = 5;
$pdf->Image('images/logoradio2.jpg', $logoX, $logoY, $logoWidth);

// Salto de línea debajo del logo
$pdf->SetY($logoY + 25);

// 2) DATOS DEL PRODUCTO (Nombre y Número de Serie)
$pdf->SetFont('Arial','B',10);
$pdf->Cell(0,5,utf8_decode($producto['nombre']),0,1,'C');
$pdf->SetFont('Arial','',9);
$pdf->Cell(0,5,utf8_decode("N° Serie: " . $producto['numero_serie']),0,1,'C');
$pdf->Ln(3);

// 3) QR CENTRADO
$qrWidth = 25;
$qrX = ($pageWidth - $qrWidth) / 2;
$qrY = $pdf->GetY();
$pdf->Image($tempQRPath, $qrX, $qrY, $qrWidth);

// Eliminar la imagen temporal del QR
unlink($tempQRPath);

// Mostrar el PDF en el navegador
header("Content-Type: application/pdf");
header("Content-Disposition: inline; filename=etiqueta_producto.pdf");
$pdf->Output('I');
?>
