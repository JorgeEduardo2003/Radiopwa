<?php
session_start();
require_once 'conexion.php';

if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}
if (!isset($_GET['id'])) {
    echo "ID de artículo no especificado.";
    exit();
}

$id = intval($_GET['id']);
$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Se recoge el nuevo status elegido por el usuario
    $nuevo_status = trim($_POST['nuevo_status'] ?? '');
    if (empty($nuevo_status)) {
        $error = "Debe seleccionar un status.";
    } else {
        $stmt = $conn->prepare("UPDATE articulos SET status = ? WHERE idArticulo = ?");
        $stmt->bind_param("si", $nuevo_status, $id);
        if ($stmt->execute()) {
            echo "<script>alert('Artículo actualizado a {$nuevo_status}'); window.location.href='main.php';</script>";
            exit();
        } else {
            $error = "Error al actualizar: " . $conn->error;
        }
        $stmt->close();
    }
}

$stmt = $conn->prepare("SELECT nombre, status FROM articulos WHERE idArticulo = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    echo "Artículo no encontrado.";
    exit();
}
$articulo = $result->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Actualizar Status del Artículo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { 
      background-color: #1E1E2F; 
      color: #FFFFFF; 
    }
    .modal-content { 
      background-color: #2A2A3C; 
      border-radius: 10px; 
      text-align: center; 
    }
    .btn-close { filter: invert(1); }
    .toast-container { 
      position: fixed; 
      top: 20px; 
      right: 20px; 
      z-index: 1050; 
    }
  </style>
</head>
<body class="d-flex align-items-center justify-content-center vh-100">
  <div class="modal show d-block">
    <div class="modal-dialog">
      <div class="modal-content">
        <form method="POST" action="">
          <div class="modal-header">
            <h5 class="modal-title w-100">Actualizar Status del Artículo</h5>
            <a href="main.php" class="btn-close"></a>
          </div>
          <div class="modal-body">
            <?php if(!empty($error)): ?>
              <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <p>
              El artículo: <strong><?= htmlspecialchars($articulo['nombre']) ?></strong><br>
              Tiene el status actual: <strong><?= htmlspecialchars($articulo['status']) ?></strong>
            </p>
            <p>Seleccione el nuevo status:</p>
            <div class="mb-3">
              <select class="form-select" name="nuevo_status" required>
                <option value="">Seleccione un status</option>
                <option value="activo" <?= $articulo['status'] == 'activo' ? 'selected' : '' ?>>Activo</option>
                <option value="inactivo" <?= $articulo['status'] == 'inactivo' ? 'selected' : '' ?>>Inactivo</option>
                <option value="en mantenimiento" <?= $articulo['status'] == 'en mantenimiento' ? 'selected' : '' ?>>En Mantenimiento</option>
              </select>
            </div>
          </div>
          <div class="modal-footer d-flex justify-content-between">
            <button type="submit" class="btn btn-primary">Actualizar Status</button>
            <a href="main.php" class="btn btn-secondary">Cancelar</a>
          </div>
        </form>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
