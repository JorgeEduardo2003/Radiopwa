<?php
require_once 'conexion.php';

$mensaje = "";
$tipoMensaje = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre_marca = trim($_POST['nombre_marca'] ?? '');
    if (empty($nombre_marca)) {
        $mensaje = "El nombre de la marca no puede estar vacío.";
        $tipoMensaje = "danger";
    } else {
        $stmt = $conn->prepare("INSERT INTO marcas (nombre) VALUES (?)");
        $stmt->bind_param("s", $nombre_marca);
        if ($stmt->execute()) {
            echo "<script>alert('Marca agregada exitosamente'); window.location.href='main.php';</script>";
            exit();
        } else {
            $mensaje = "Error al agregar la marca: " . $conn->error;
            $tipoMensaje = "danger";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Agregar Marca - Radio Autlan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #1E1E2F; color: #FFFFFF; }
    .modal-content { background-color: #2A2A3C; border-radius: 10px; text-align: center; }
    .btn-close { filter: invert(1); }
    .toast-container { position: fixed; top: 20px; right: 20px; z-index: 1050; }
  </style>
</head>
<body class="d-flex align-items-center justify-content-center vh-100">
  <div class="toast-container">
    <?php if(!empty($mensaje)): ?>
      <div class="toast show text-bg-<?= $tipoMensaje ?>" role="alert">
        <div class="toast-body"><?= htmlspecialchars($mensaje) ?></div>
      </div>
    <?php endif; ?>
  </div>
  <!-- Modal para agregar marca -->
  <div class="modal show d-block" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <form action="" method="POST">
          <div class="modal-header">
            <h5 class="modal-title w-100">Agregar Marca</h5>
            <a href="main.php" class="btn-close"></a>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label for="nombre_marca" class="form-label">Nombre de la Marca</label>
              <input type="text" class="form-control" id="nombre_marca" name="nombre_marca" required>
            </div>
          </div>
          <div class="modal-footer d-flex justify-content-between">
            <button type="submit" class="btn btn-primary">Agregar Marca</button>
            <a href="main.php" class="btn btn-secondary">Cancelar</a>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!-- Cargar Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
