<?php
session_start();
require_once 'conexion.php';

if(!isset($_SESSION['usuario'])){
   header("Location: index.php");
   exit();
}

if(!isset($_POST['codigoSolicitante']) || !isset($_POST['fechaLimite']) || !isset($_POST['articulos'])){
    die("Faltan datos del préstamo.");
}

$codigoSolicitante = $_POST['codigoSolicitante'];
$fechaLimite = $_POST['fechaLimite'];
$articulosStr = $_POST['articulos'];
$articulosArray = explode(',', $articulosStr);

$stmt = $conn->prepare("SELECT idSolicitante FROM solicitantes WHERE codigoInstitucion = ? OR idSolicitante = ?");
$stmt->bind_param("ss", $codigoSolicitante, $codigoSolicitante);
$stmt->execute();
$result = $stmt->get_result();
if($result->num_rows == 0){
    die("Solicitante no encontrado.");
}
$solicitante = $result->fetch_assoc();
$idSolicitante = $solicitante['idSolicitante'];

$username = $_SESSION['usuario'];
$stmtUser = $conn->prepare("SELECT ID FROM users WHERE user = ?");
$stmtUser->bind_param("s", $username);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
if($resultUser->num_rows == 0){
    die("Usuario no encontrado.");
}
$user = $resultUser->fetch_assoc();
$idAutorizador = $user['ID'];

$stmtInsert = $conn->prepare("INSERT INTO prestamos (idSolicitante, idAutorizador, idArticulo, fecha_limite_devolucion) VALUES (?, ?, ?, ?)");
foreach($articulosArray as $idArticulo){
    $idArticulo = trim($idArticulo);
    if(empty($idArticulo)) continue;
    $stmtStatus = $conn->prepare("SELECT status FROM articulos WHERE idArticulo = ?");
    $stmtStatus->bind_param("i", $idArticulo);
    $stmtStatus->execute();
    $resultStatus = $stmtStatus->get_result();
    if($rowStatus = $resultStatus->fetch_assoc()){
        $currentStatus = $rowStatus['status'];
        if($currentStatus !== 'activo'){
            $stmtStatus->close();
            continue;
        }
    } else {
        $stmtStatus->close();
        continue;
    }
    $stmtStatus->close();
    
    $stmtInsert->bind_param("iiis", $idSolicitante, $idAutorizador, $idArticulo, $fechaLimite);
    $stmtInsert->execute();
    
    $stmtUpdate = $conn->prepare("UPDATE articulos SET status = 'en prestamo' WHERE idArticulo = ?");
    $stmtUpdate->bind_param("i", $idArticulo);
    $stmtUpdate->execute();
    $stmtUpdate->close();
}
$stmtInsert->close();

header("Location: main.php");
exit();
?>
