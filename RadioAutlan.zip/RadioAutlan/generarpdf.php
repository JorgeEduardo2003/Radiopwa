<?php
session_start(); // Iniciar sesión para acceder a $_SESSION

require('fpdf.php');
require_once 'conexion.php';

// --------------------------------------------------------------
// CONFIGURACIÓN DE CONEXIÓN (asegurar UTF-8)
// --------------------------------------------------------------
if (!$conn) {
    die('Error al conectar a la base de datos: ' . mysqli_connect_error());
}
$conn->set_charset('utf8');

// --------------------------------------------------------------
// OBTENCIÓN Y VALIDACIÓN DE IDS
// --------------------------------------------------------------
if (!isset($_GET['ids'])) {
    die('No se proporcionaron IDs.');
}
$ids = explode(',', $_GET['ids']);
$ids = array_filter($ids, function($id) { return is_numeric($id); });
if (empty($ids)) {
    die('No hay IDs válidos.');
}
$ids = array_map('intval', $ids);
$idList = implode(',', $ids);

// --------------------------------------------------------------
// CONSULTA A LA BASE DE DATOS
// --------------------------------------------------------------
$sql = "
    SELECT 
        a.idArticulo     AS codigo,
        a.clasificacion  AS clasificacion,
        a.nombre         AS nombre_articulo,
        a.descripcion    AS descripcion,
        a.numero_serie   AS serie,
        a.modelo,
        m.nombre         AS marca,
        u.nombreCompleto AS resguardante,
        ub.nombre        AS ubicacion,
        a.valor,
        a.origen,
        a.status
    FROM articulos a
    JOIN marcas m       ON a.idMarca     = m.idMarca
    JOIN users u        ON a.resguardante = u.ID
    JOIN ubicaciones ub ON a.ubicacion   = ub.idUbicacion
    WHERE a.idArticulo IN ($idList)
    ORDER BY a.idArticulo ASC
";
$result = $conn->query($sql);
if (!$result) {
    die('Error en la consulta: ' . $conn->error);
}
$totalArticulos = $result->num_rows;
if ($totalArticulos === 0) {
    die('No se encontraron artículos para los IDs proporcionados.');
}

// --------------------------------------------------------------
// CLASE PDF PERSONALIZADA CON FPDF
// --------------------------------------------------------------
class PDF extends FPDF
{
    var $widths;

    function SetWidths($w) {
        $this->widths = $w;
    }

    function DottedLine($x1, $y1, $x2, $y2, $dashLength = 1, $gap = 1) {
        $dx = $x2 - $x1; $dy = $y2 - $y1;
        $dist = sqrt($dx*$dx + $dy*$dy);
        $dashCount = floor($dist / ($dashLength + $gap));
        for ($i = 0; $i < $dashCount; $i++) {
            $xS = $x1 + ($dx * ($i * ($dashLength + $gap)) / $dist);
            $yS = $y1 + ($dy * ($i * ($dashLength + $gap)) / $dist);
            $xE = $x1 + ($dx * ($i * ($dashLength + $gap) + $dashLength) / $dist);
            $yE = $y1 + ($dy * ($i * ($dashLength + $gap) + $dashLength) / $dist);
            $this->Line($xS, $yS, $xE, $yE);
        }
    }

    // Encabezado rediseñado
    function Header()
    {
        $pageWidth = $this->GetPageWidth();
        $hHeader   = 30;

        // Fondo gris claro del header
        $this->SetFillColor(240,240,240);
        $this->Rect(0, 0, $pageWidth, $hHeader, 'F');

        // Logo (altura máxima 14mm)
        $this->Image('images/logoradio2png.png', 15, 8, 0, 14);

        // Títulos institucionales
        $this->SetFont('Arial','B',14);
        $this->SetTextColor(30,30,30);
        $this->SetXY(55, 10);
        $this->Cell(0, 6, utf8_decode('Radio Universidad de Guadalajara AUTLAN'), 0,1,'L');
        $this->SetFont('Arial','',12);
        $this->SetX(55);
        $this->Cell(0, 6, utf8_decode('Reporte de inventario'), 0,1,'L');

        // Subtítulos en la esquina superior derecha
        $this->SetFont('Arial','B',10);
        $this->SetXY(-70, 10);
        $this->Cell(60, 6, utf8_decode('UNIDAD DE CONTROL PATRIMONIAL'), 0,1,'C');
        $this->SetXY(-70, 16);
        $this->Cell(60, 6, utf8_decode('RESGUARDO GENERAL DE BIENES'), 0,1,'C');

        // Línea divisora
        $this->SetDrawColor(200,200,200);
        $this->SetLineWidth(0.5);
        $this->Line(10, $hHeader, $pageWidth - 10, $hHeader);

        // Espacio antes del cuerpo
        $this->Ln(12);
    }

    function Footer()
    {
        $pageWidth = $this->GetPageWidth();
        $y = $this->GetY();
        $this->SetDrawColor(200,200,200);
        $this->Line(10, $y, $pageWidth - 10, $y);
        $this->SetFont('Arial','I',8);
        $this->Cell(0,10,utf8_decode('Página ').$this->PageNo().' de {nb}',0,0,'C');
    }

    function Row($data)
    {
        $nb = 0;
        foreach ($data as $i => $cell) {
            $nb = max($nb, $this->NbLines($this->widths[$i], $cell));
        }
        $h = 4.5 * $nb;
        $this->CheckPageBreak($h);
        foreach ($data as $i => $cell) {
            $x = $this->GetX(); $y = $this->GetY();
            $this->MultiCell($this->widths[$i], 4.5, $cell, 0, 'L');
            $this->SetXY($x + $this->widths[$i], $y);
        }
        $this->Ln($h);
        $this->DottedLine(10, $this->GetY(), $this->GetPageWidth() - 10, $this->GetY());
    }

    function CheckPageBreak($h)
    {
        if ($this->GetY() + $h > $this->PageBreakTrigger) {
            $this->AddPage($this->CurOrientation);
        }
    }

    function NbLines($w, $txt)
    {
        $cw = &$this->CurrentFont['cw'];
        if ($w == 0) {
            $w = $this->GetPageWidth() - $this->rMargin - $this->x;
        }
        $wmax = ($w - 2*$this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', $txt);
        $nb = strlen($s);
        if ($nb > 0 && $s[$nb-1] == "\n") {
            $nb--;
        }
        $sep = -1; $i = 0; $j = 0; $l = 0; $nl = 1;
        while ($i < $nb) {
            $c = $s[$i];
            if ($c == "\n") {
                $i++; $sep = -1; $j = $i; $l = 0; $nl++; continue;
            }
            if ($c == ' ') {
                $sep = $i;
            }
            $l += $cw[$c];
            if ($l > $wmax) {
                if ($sep == -1) {
                    if ($i == $j) $i++;
                } else {
                    $i = $sep + 1;
                }
                $sep = -1; $j = $i; $l = 0; $nl++;
            } else {
                $i++;
            }
        }
        return $nl;
    }
}

// --------------------------------------------------------------
// GENERACIÓN DEL PDF
// --------------------------------------------------------------
setlocale(LC_TIME, 'es_ES.UTF-8');
$dependencia     = "Radio Universidad De Guadalajara";
$titular         = "2716666 - ELIA GUADALUPE MACIAS VARGAS";
$fecha           = strftime('%d de %B del %Y %H:%M:%S');
$nombreCompleto  = isset($_SESSION['nombreCompleto']) ? $_SESSION['nombreCompleto'] : ''; // Se obtiene nombre completo de sesión

$pdf = new PDF('L','mm','A4');
$pdf->AliasNbPages();
$pdf->SetMargins(10,10,10);
$pdf->SetAutoPageBreak(true,20);
$pdf->AddPage();

// Franja de datos justo debajo del header
$yFranja   = $pdf->GetY();
$pageWidth = $pdf->GetPageWidth();
$pdf->SetFillColor(230,230,230);
$pdf->Rect(10, $yFranja, $pageWidth - 20, 14, 'F'); // Aumentado alto de 10 a 14mm para cubrir mejor el fondo
$pdf->SetXY(12, $yFranja + 3);
$pdf->Cell(($pageWidth - 20)/2, 5, utf8_decode("DEPENDENCIA: $dependencia"), 0, 0, 'L');
$pdf->Cell(($pageWidth - 20)/2, 5, utf8_decode("TITULAR: $titular"), 0, 1, 'L');
$pdf->SetX(12);
$pdf->Cell(($pageWidth - 20)/2, 5, utf8_decode("FECHA: $fecha"), 0, 0, 'L');
$pdf->Cell(($pageWidth - 20)/2, 5, utf8_decode("GENERÓ REPORTE: $nombreCompleto"), 0, 1, 'L'); // Agregado nombre completo
$pdf->Ln(4);

// Título de tabla y total
$pdf->SetFont('Arial','B',9);
$pdf->Cell(($pageWidth - 20)/2, 5, utf8_decode('APARTADO DE MOBILIARIO:'), 0, 0, 'L');
$pdf->Cell(($pageWidth - 20)/2, 5, utf8_decode("TOTAL ARTÍCULOS: $totalArticulos"), 0, 1, 'R');
$pdf->Ln(2);

// Encabezado de tabla (12 columnas, incluyendo CLASIFICACIÓN)
$headers = [
    'CÓDIGO','CLASIFICACIÓN','NOMBRE','DESCRIPCIÓN','SERIE','MODELO',
    'MARCA','RESGUARDANTE','UBICACIÓN','VALOR','ORIGEN','ESTATUS'
];
$colCount = count($headers);
$usable   = $pageWidth - 20;
$widths   = array_fill(0, $colCount, $usable / $colCount);
$pdf->SetWidths($widths);

$pdf->SetFont('Arial','B',8);
$pdf->SetFillColor(230,230,230);
foreach ($headers as $i => $title) {
    $pdf->Cell($widths[$i], 6, utf8_decode($title), 0, 0, 'C', true);
}
$pdf->Ln();
$pdf->DottedLine(10, $pdf->GetY(), $pageWidth - 10, $pdf->GetY());

// Filas de datos
$pdf->SetFont('Arial','',8);
while ($row = $result->fetch_assoc()) {
    $data = [
        $row['codigo'],
        utf8_decode($row['clasificacion']),
        utf8_decode($row['nombre_articulo']),
        utf8_decode($row['descripcion']),
        utf8_decode($row['serie']),
        utf8_decode($row['modelo']),
        utf8_decode($row['marca']),
        utf8_decode($row['resguardante']),
        utf8_decode($row['ubicacion']),
        '$'.number_format($row['valor'], 2, '.', ','),
        utf8_decode($row['origen']),
        utf8_decode(ucfirst($row['status']))
    ];
    $pdf->Row($data);
}

$pdf->Output('I','Inventario_Resguardo.pdf');
exit;
?>
