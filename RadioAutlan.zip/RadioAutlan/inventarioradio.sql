-- Tabla de usuarios
CREATE TABLE
  `users` (
    `ID` int (100) NOT NULL AUTO_INCREMENT,
    `user` varchar(200) NOT NULL,
    `pass` varchar(255) NOT NULL,
    `codigo` varchar(12) NOT NULL,
    `nombreCompleto` varchar(300) NOT NULL,
    `tipo` ENUM ('admin', 'usuario') NOT NULL,
    PRIMARY KEY (`ID`)
  );

-- Tabla de marcas
CREATE TABLE
  `marcas` (
    `idMarca` int NOT NULL AUTO_INCREMENT,
    `nombre` varchar(100) NOT NULL,
    PRIMARY KEY (`idMarca`)
  );

-- Tabla de solicitantes
CREATE TABLE
  `solicitantes` (
    `idSolicitante` int NOT NULL AUTO_INCREMENT,
    `codigoInstitucion` varchar(50) NOT NULL,
    `nombreCompleto` varchar(300) NOT NULL,
    `cargo` ENUM ('estudiante', 'trabajador', 'maestro') NOT NULL,
    PRIMARY KEY (`idSolicitante`)
  );

-- Tabla de ubicaciones (nueva)
CREATE TABLE
  `ubicaciones` (
    `idUbicacion` INT NOT NULL AUTO_INCREMENT,
    `nombre` VARCHAR(100) NOT NULL,
    PRIMARY KEY (`idUbicacion`)
  );

-- Tabla de articulos (modificada)
CREATE TABLE
  `articulos` (
    `idArticulo` int NOT NULL AUTO_INCREMENT,
    `nombre` varchar(200) NOT NULL,
    `idMarca` int NOT NULL,
    `modelo` varchar(100) DEFAULT NULL,
    `valor` decimal(10, 2) DEFAULT NULL,
    `descripcion` text DEFAULT NULL,
    `clasificacion` varchar(100) DEFAULT NULL,
    `numero_serie` varchar(100) DEFAULT NULL,
    -- origen ajustado a nuevos valores
    `origen` ENUM ('PATME', 'SICI', 'Histórico') DEFAULT NULL,
    `status` ENUM (
      'activo',
      'inactivo',
      'en mantenimiento',
      'en prestamo'
    ) DEFAULT NULL,
    `vinculado` ENUM ('si', 'no') DEFAULT 'no',
    -- tipo ajustado a nuevos valores
    `tipo` ENUM ('equipo', 'mobiliario') DEFAULT NULL,
    `resguardante` int NOT NULL,
    -- nueva columna de ubicación
    `ubicacion` int NOT NULL,
    PRIMARY KEY (`idArticulo`),
    CONSTRAINT fk_articulo_marca FOREIGN KEY (`idMarca`) REFERENCES `marcas` (`idMarca`),
    CONSTRAINT fk_articulo_resguardante FOREIGN KEY (`resguardante`) REFERENCES `users` (`ID`),
    CONSTRAINT fk_articulo_ubicacion FOREIGN KEY (`ubicacion`) REFERENCES `ubicaciones` (`idUbicacion`)
  );

-- Tabla de prestamos
CREATE TABLE
  `prestamos` (
    `idPrestamo` int NOT NULL AUTO_INCREMENT,
    `idSolicitante` int NOT NULL,
    `idAutorizador` int NOT NULL,
    `idArticulo` int NOT NULL,
    `fecha_limite_devolucion` DATE NOT NULL,
    PRIMARY KEY (`idPrestamo`),
    CONSTRAINT fk_prestamo_solicitante FOREIGN KEY (`idSolicitante`) REFERENCES `solicitantes` (`idSolicitante`),
    CONSTRAINT fk_prestamo_autorizador FOREIGN KEY (`idAutorizador`) REFERENCES `users` (`ID`),
    CONSTRAINT fk_prestamo_articulo FOREIGN KEY (`idArticulo`) REFERENCES `articulos` (`idArticulo`)
  );

INSERT INTO
  `users` (
    `user`,
    `pass`,
    `codigo`,
    `nombreCompleto`,
    `tipo`
  )
VALUES
  (
    'admin',
    'admin',
    '2716666',
    'ELIA GUADALUPE MACIAS VARGAS',
    'admin'
  );

INSERT INTO
  `marcas` (`nombre`)
VALUES
  ('AOC'),
  ('HP'),
  ('ADATA'),
  ('STEREN'),
  ('PRO?SKIT'),
  ('BROTHER'),
  ('BEHRINGER'),
  ('FACEAXS'),
  ('LENOVO'),
  ('SIN MARCA'),
  ('BK PRECISION'),
  ('BIRD'),
  ('MCI (MICRO COMUNICATION S, INC)'),
  ('AKG'),
  ('COMREX'),
  ('KHOLER'),
  ('ISB  (ISB SOLA BASIC)'),
  ('WD'),
  ('SENNHEISER'),
  ('SHURE'),
  ('TASCAM'),
  ('DELL'),
  ('WHEATSTONE'),
  ('BALAM RUSH'),
  ('QUIAN'),
  ('AUDIO TECHNICA'),
  ('MARANTZ'),
  ('HARRIS'),
  ('INOVONICS'),
  ('ORBAN'),
  ('BROAD CAST ELLECTRONICS'),
  ('BROADCAST ELLECTRONICS'),
  ('MACKIE'),
  ('SOLA BASIC'),
  ('ELECTROVOICE'),
  ('BACO'),
  ('HALLON'),
  ('CANON'),
  ('ELECTRO VOICE'),
  ('KINGSTOM'),
  ('IOMEGA'),
  ('LETRERO AL AIRE (DICIMEX)'),
  ('KOMBO 500'),
  ('EPSON'),
  ('HP LASERJET');

INSERT INTO
  `solicitantes` (`codigoInstitucion`, `nombreCompleto`, `cargo`)
VALUES
  ('123', 'Javier Lopez', 'estudiante'),
  ('444', 'Jose Villareal', 'estudiante'),
  ('432', 'Carlos', 'estudiante');

INSERT INTO
  `ubicaciones` (`nombre`)
VALUES
  ('Oficina Principal'),
  ('Almacén'),
  ('Sala de Reuniones'),
  ('Laboratorio'),
  ('Área de Producción');

INSERT INTO
  `articulos` (
    `nombre`,
    `idMarca`,
    `modelo`,
    `valor`,
    `descripcion`,
    `clasificacion`,
    `numero_serie`,
    `origen`,
    `status`,
    `vinculado`,
    `tipo`,
    `resguardante`,
    `ubicacion`
  )
VALUES
  (
    'MONITOR DE 23" LED COLOR NEGRO',
    1,
    '230LM000125',
    2778.20,
    'Monitor de 23" LED color negro',
    'MONITOR',
    'BLNDB9A000815',
    'PATME',
    'activo',
    'no',
    'equipo',
    1,
    1
  ),
  (
    'CPU HP PRO 6305 SFF',
    2,
    'COMPAQ PRO 6305',
    12221.79,
    'CPU HP PRO 6305 SFF edición p/audio 1 TB/4GB RAM/DVD RW color negro',
    'C.P.U.',
    'MXL4011NCW',
    'PATME',
    'activo',
    'no',
    'equipo',
    1,
    1
  ),
  (
    'CPU HP PRO 6305 SFF',
    2,
    'COMPAQ PRO 6305',
    12221.81,
    'CPU HP PRO 6305 SFF edición p/audio 1 TB/4GB RAM/DVD RW color negro',
    'C.P.U.',
    'MXL3521JDV',
    'PATME',
    'activo',
    'no',
    'equipo',
    1,
    1
  ),
  (
    'MONITOR DE 23" LED COLOR NEGRO',
    1,
    '230LM0025',
    2778.20,
    'Monitor de 23" LED color negro',
    'MONITOR',
    'BLNDB9A000808',
    'PATME',
    'activo',
    'no',
    'equipo',
    1,
    1
  ),
  (
    'DISCO DURO EXTERNO, 3TB',
    3,
    'NOBILITY NH03',
    2923.68,
    'Disco duro externo, 3TB, 3.5, color negro',
    'DISCO DURO',
    '1E0220350453',
    'PATME',
    'activo',
    'no',
    'equipo',
    1,
    2
  ),
  (
    'RADIO INTERCOMUNICADOR COLOR NEGRO',
    4,
    'RAD-510',
    1190.00,
    'Radio intercomunicador color negro',
    'RADIO COMUNICADOR',
    '69300418',
    'PATME',
    'activo',
    'no',
    'equipo',
    1,
    3
  ),
  (
    'RADIO INTERCOMUNICADOR COLOR NEGRO',
    4,
    'RAD-510',
    1190.00,
    'Radio intercomunicador color negro',
    'RADIO COMUNICADOR',
    '69300654',
    'PATME',
    'activo',
    'no',
    'equipo',
    1,
    3
  ),
  (
    'PORTAFOLIO DE HERRAMIENTAS (CAJA CON 38 PIEZAS)',
    5,
    'N/A',
    2090.01,
    'Portafolio de herramientas (caja con 38 piezas) color azul marino',
    'CAJA DE HERRAMIENTAS',
    'N/A',
    'PATME',
    'activo',
    'no',
    'equipo',
    1,
    4
  ),
  (
    'MULTIFUNCIONAL',
    6,
    'MFC-7360N',
    3502.93,
    'Multifuncional (impresora láser multifuncional color gris)',
    'MULTIFUNCIONAL',
    'U62700D3N480149',
    'PATME',
    'activo',
    'no',
    'equipo',
    1,
    5
  ),
  (
    'AMPLIFICADOR-DISTRIBUIDOR DE AURICULARES',
    7,
    'HA8000',
    3615.14,
    'Amplificador-distribuidor de auriculares de 8 canales y alta potencia',
    'DISTRIBUIDOR',
    'S1201921185',
    'PATME',
    'activo',
    'no',
    'equipo',
    1,
    6
  );