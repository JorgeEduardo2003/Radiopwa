<?php
require_once 'conexion.php';

$mensaje = "";
$tipoMensaje = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $codigoInstitucion = trim($_POST['codigoInstitucion'] ?? '');
    $nombreCompleto    = trim($_POST['nombreCompleto'] ?? '');
    $cargo             = trim($_POST['cargo'] ?? '');
    
    if (empty($codigoInstitucion) || empty($nombreCompleto) || empty($cargo)) {
        $mensaje = "Todos los campos son obligatorios.";
        $tipoMensaje = "danger";
    } else {
        $stmt = $conn->prepare("INSERT INTO solicitantes (codigoInstitucion, nombreCompleto, cargo) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $codigoInstitucion, $nombreCompleto, $cargo);
        if ($stmt->execute()) {
            echo "<script>alert('Solicitante agregado exitosamente'); window.location.href='main.php';</script>";
            exit();
        } else {
            $mensaje = "Error al agregar el solicitante: " . $conn->error;
            $tipoMensaje = "danger";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Agregar Solicitante - Radio Autlan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #1E1E2F; color: #FFFFFF; }
    .modal-content { background-color: #2A2A3C; border-radius: 10px; text-align: center; }
    .btn-close { filter: invert(1); }
    .toast-container { position: fixed; top: 20px; right: 20px; z-index: 1050; }
  </style>
</head>
<body class="d-flex align-items-center justify-content-center vh-100">
  <div class="toast-container">
    <?php if(!empty($mensaje)): ?>
      <div class="toast show text-bg-<?= $tipoMensaje ?>" role="alert">
        <div class="toast-body"><?= htmlspecialchars($mensaje) ?></div>
      </div>
    <?php endif; ?>
  </div>
  <!-- Modal para agregar solicitante -->
  <div class="modal show d-block" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <form action="" method="POST">
          <div class="modal-header">
            <h5 class="modal-title w-100">Agregar Solicitante</h5>
            <a href="main.php" class="btn-close"></a>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label for="codigoInstitucion" class="form-label">Código Institución</label>
              <input type="text" class="form-control" id="codigoInstitucion" name="codigoInstitucion" required>
            </div>
            <div class="mb-3">
              <label for="nombreCompleto" class="form-label">Nombre Completo</label>
              <input type="text" class="form-control" id="nombreCompleto" name="nombreCompleto" required>
            </div>
            <div class="mb-3">
              <label for="cargo" class="form-label">Cargo</label>
              <select class="form-select" id="cargo" name="cargo" required>
                <option value="estudiante">Estudiante</option>
                <option value="trabajador">Trabajador</option>
                <option value="maestro">Maestro</option>
              </select>
            </div>
          </div>
          <div class="modal-footer d-flex justify-content-between">
            <button type="submit" class="btn btn-primary">Agregar Solicitante</button>
            <a href="main.php" class="btn btn-secondary">Cancelar</a>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!-- Cargar Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
