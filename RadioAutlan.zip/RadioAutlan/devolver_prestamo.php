<?php
session_start();
require_once 'conexion.php';

if(!isset($_SESSION['usuario'])){
   header("Location: index.php");
   exit();
}

// Verificar que se hayan recibido los datos del formulario
if(!isset($_POST['articulos'])){
    die("No se han recibido los artículos.");
}

$articulosStr = $_POST['articulos'];
$articulosArray = explode(',', $articulosStr);

// Para este proceso, se actualizará el status de cada artículo SOLO si está en 'en prestamo'
$stmtUpdate = $conn->prepare("UPDATE articulos SET status = 'activo' WHERE idArticulo = ?");
foreach($articulosArray as $idArticulo){
    $idArticulo = trim($idArticulo);
    if(empty($idArticulo)) continue;
    
    // Verificar el status actual del artículo
    $stmtStatus = $conn->prepare("SELECT status FROM articulos WHERE idArticulo = ?");
    $stmtStatus->bind_param("i", $idArticulo);
    $stmtStatus->execute();
    $resultStatus = $stmtStatus->get_result();
    if($rowStatus = $resultStatus->fetch_assoc()){
        $currentStatus = $rowStatus['status'];
        // Solo se pueden devolver artículos que estén en 'en prestamo'
        if($currentStatus !== 'en prestamo'){
            $stmtStatus->close();
            continue;
        }
    } else {
        $stmtStatus->close();
        continue;
    }
    $stmtStatus->close();
    
    // Actualizar el status a 'activo'
    $stmtUpdate->bind_param("i", $idArticulo);
    $stmtUpdate->execute();
}
$stmtUpdate->close();

// Redirigir a main.php después de la actualización
header("Location: main.php");
exit();
?>
