<?php
ob_start();
session_start();
require_once 'conexion.php';

$errorLogin = '';
$errorRegister = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Procesar login
    if (isset($_POST['form_type']) && $_POST['form_type'] === 'login') {
        if (isset($_POST['usuario'], $_POST['password'])) {
            $usuario = trim($_POST['usuario']);
            $password = trim($_POST['password']);

            // Se modifica la consulta para traer también el campo "tipo"
            if ($stmt = $conn->prepare("SELECT ID, user, codigo, nombreCompleto, tipo FROM users WHERE user = ? AND pass = ?")) {
                $stmt->bind_param("ss", $usuario, $password);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result && $result->num_rows === 1) {
                    // Obtener datos del usuario y guardarlos en la sesión
                    $row = $result->fetch_assoc();
                    $_SESSION['usuario'] = $row['user'];
                    $_SESSION['codigo'] = $row['codigo'];
                    $_SESSION['id'] = $row['ID'];
                    $_SESSION['nombreCompleto'] = $row['nombreCompleto'];
                    $_SESSION['tipo'] = $row['tipo']; // Se guarda el tipo de usuario (admin o usuario)

                    header("Location: main.php");
                    exit();
                } else {
                    $errorLogin = "Usuario o contraseña incorrectos.";
                }
                $stmt->close();
            } else {
                $errorLogin = "Error en la consulta: " . $conn->error;
            }
        } else {
            $errorLogin = "Por favor, complete ambos campos.";
        }
    }
    // Procesar registro
    elseif (isset($_POST['form_type']) && $_POST['form_type'] === 'register') {
        if (isset($_POST['new-user'], $_POST['nombre'], $_POST['new-password'], $_POST['confirm-password'], $_POST['roles'])) {
            $newUser = trim($_POST['new-user']);
            $nombre = trim($_POST['nombre']);
            $password = trim($_POST['new-password']);
            $confirmPassword = trim($_POST['confirm-password']);
            $rol = trim($_POST['roles']);

            if ($password !== $confirmPassword) {
                $errorRegister = "Las contraseñas no coinciden.";
            } else {
                // Verificar si el usuario ya existe
                if ($stmt = $conn->prepare("SELECT * FROM users WHERE user = ?")) {
                    $stmt->bind_param("s", $newUser);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result && $result->num_rows > 0) {
                        $errorRegister = "El usuario ya existe. Por favor, elija otro.";
                    }
                    $stmt->close();
                }

                // Si no hay error, inserta el usuario
                if (empty($errorRegister)) {
                    // Genera un código, por ejemplo "C" seguido de 3 dígitos
                    $codigo = 'C' . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
                    if ($stmt = $conn->prepare("INSERT INTO users (user, pass, codigo, nombreCompleto, tipo) VALUES (?, ?, ?, ?, ?)")) {
                        $stmt->bind_param("sssss", $newUser, $password, $codigo, $nombre, $rol);
                        $stmt->execute();
                        $stmt->close();
                        // Tras registro exitoso, redirige a la misma página
                        header("Location: index.php");
                        exit();
                    } else {
                        $errorRegister = "Error en la consulta: " . $conn->error;
                    }
                }
            }
        } else {
            $errorRegister = "Complete todos los campos.";
        }
    }
}
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login - Radio Autlan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root {
      --color1: #160d18; /* Fondo principal muy oscuro */
      --color2: #23145b; /* Fondo de inputs y navbar */
      --color3: #09456c; /* Fondo de tarjetas y modal */
      --color4: #026f6e; /* Botones y bordes */
      --color5: #1ca39e; /* Enlaces destacados */
      --color6: #ffffff; /* Texto */
      --color7: rgb(173, 135, 19); /* Enlaces destacados alternativos */
    }
    body {
      background-color: var(--color1);
      color: var(--color6);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      margin: 0;
      font-family: sans-serif;
    }
    .navbar {
      background-color: var(--color2);
    }
    .login-container {
      width: 100%;
      max-width: 400px;
    }
    .card {
      border: none;
      border-radius: 8px;
      overflow: hidden;
    }
    .card-body {
      background-color: var(--color3);
      padding: 30px;
    }
    .card-title {
      color: var(--color6);
      margin-bottom: 1rem;
    }
    .btn-primary {
      background-color: var(--color4);
      border-color: var(--color4);
    }
    .btn-primary:hover {
      background-color: var(--color5);
      border-color: var(--color5);
    }
    .form-control, .form-select {
      background-color: var(--color2);
      color: var(--color6);
      border: 1px solid var(--color4);
      text-align: left;
    }
    label {
      color: var(--color6);
    }
    p.mt-3 {
      color: var(--color6) !important;
    }
    p.mt-3 a {
      color: var(--color6) !important;
      font-weight: bold;
      text-decoration: underline;
    }
    /* Estilos para el modal de registro */
    .modal-content {
      background-color: var(--color3);
      color: var(--color6);
      border: none;
      border-radius: 8px;
    }
    .modal-title {
      text-align: center;
    }
    .modal-body .alert {
      display: none;
    }
    .modal-body .alert.show {
      display: block;
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">
        <img src="images/logoudg.png" alt="Logo Radio Autlan" width="60">
      </a>
    </div>
  </nav>

  <!-- Contenedor del Login -->
  <div class="login-container">
    <div class="card shadow">
      <div class="card-body">
        <h3 class="card-title">Iniciar sesión</h3>
        <?php if (!empty($errorLogin)): ?>
          <div class="alert alert-danger" role="alert">
            <?php echo $errorLogin; ?>
          </div>
        <?php endif; ?>
        <form action="index.php" method="post" novalidate>
          <!-- Identificador del formulario de login -->
          <input type="hidden" name="form_type" value="login">
          <div class="mb-3">
            <label for="usuario" class="form-label">Usuario</label>
            <input type="text" name="usuario" id="usuario" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="password" class="form-label">Contraseña</label>
            <input type="password" name="password" id="password" class="form-control" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Entrar</button>
        </form>
        <p class="mt-3">
          ¿No tienes cuenta? <a href="#" data-bs-toggle="modal" data-bs-target="#registroModal">Regístrate aquí</a>
        </p>
      </div>
    </div>
  </div>

  <!-- Modal de Registro -->
  <div class="modal fade" id="registroModal" tabindex="-1" aria-labelledby="registroModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <form action="index.php" method="post" novalidate>
          <!-- Identificador del formulario de registro -->
          <input type="hidden" name="form_type" value="register">
          <div class="modal-header">
            <h5 class="modal-title" id="registroModalLabel">Registro de Usuario</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
          </div>
          <div class="modal-body">
            <?php if (!empty($errorRegister)): ?>
              <div class="alert alert-danger text-center show" role="alert">
                <?php echo $errorRegister; ?>
              </div>
            <?php endif; ?>
            <div class="mb-3">
              <label for="new-user" class="form-label">Usuario</label>
              <input type="text" class="form-control" id="new-user" name="new-user" required>
            </div>
            <div class="mb-3">
              <label for="nombre" class="form-label">Nombre Completo</label>
              <input type="text" class="form-control" id="nombre" name="nombre" required>
            </div>
            <div class="mb-3">
              <label for="new-password" class="form-label">Contraseña</label>
              <input type="password" class="form-control" id="new-password" name="new-password" required>
            </div>
            <div class="mb-3">
              <label for="confirm-password" class="form-label">Confirmar Contraseña</label>
              <input type="password" class="form-control" id="confirm-password" name="confirm-password" required>
            </div>
            <div class="mb-3">
              <label for="roles" class="form-label">Selecciona un rol:</label>
              <select id="roles" name="roles" class="form-select" required>
                <option value="">Seleccione...</option>
                <option value="admin">Administrador</option>
                <option value="usuario">Usuario</option>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            <button type="submit" class="btn btn-primary">Registrarse</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS y validación para confirmar contraseñas en el registro -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Validación para confirmar que las contraseñas coincidan en el formulario de registro
    document.querySelector('form[action="index.php"][method="post"][novalidate]')?.addEventListener('submit', function(e) {
      if (this.querySelector('input[name="form_type"]').value === 'register') {
        var pass = document.getElementById('new-password').value;
        var confirmPass = document.getElementById('confirm-password').value;
        if (pass !== confirmPass) {
          e.preventDefault();
          alert("Las contraseñas no coinciden.");
          return false;
        }
      }
    });
  </script>
</body>
</html>
