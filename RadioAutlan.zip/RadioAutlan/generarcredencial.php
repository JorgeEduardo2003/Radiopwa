<?php
require_once 'conexion.php';
require('fpdf.php'); // Asegúrate de tener instalada la librería FPDF en la ruta indicada

// Verificar que se reciba el parámetro "codigo"
if (!isset($_GET['codigo']) || empty($_GET['codigo'])) {
    die("No se proporcionó el código del solicitante.");
}

$codigoInstitucion = $_GET['codigo'];

// Consultar la base de datos para obtener los datos del solicitante (excluyendo el ID)
$stmt = $conn->prepare("SELECT codigoInstitucion, nombreCompleto, cargo FROM solicitantes WHERE codigoInstitucion = ?");
$stmt->bind_param("s", $codigoInstitucion);
$stmt->execute();
$resultSolicitante = $stmt->get_result();

if ($resultSolicitante->num_rows === 0) {
    die("Solicitante no encontrado.");
}

$solicitante = $resultSolicitante->fetch_assoc();

// Encriptar el código para el QR code utilizando AES-128-ECB y la clave "UDG2025"
$clave   = "UDG2025";
$metodo  = "AES-128-ECB";
$encriptado     = openssl_encrypt($solicitante['codigoInstitucion'], $metodo, $clave);
$codigoEncriptadoURL = urlencode($encriptado); // Para incluir en la URL

// Generar la URL del QR code utilizando el servicio de qrserver.com
$qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . $codigoEncriptadoURL;

// Intentar descargar la imagen del QR
$qrImage = @file_get_contents($qrUrl);
if($qrImage === false) {
    echo "Error al generar el código QR (posible falta de conexión). Redirigiendo a la página principal...";
    header("refresh:3; url=main.php");
    exit();
}
$tempQRPath = 'temp_qr.png';
file_put_contents($tempQRPath, $qrImage);

// ==========================
// CONFIGURACIÓN DE LA TARJETA
// ==========================
// Para un formato vertical estilo tarjeta de presentación:
//   - Ancho ~ 54 mm
//   - Alto ~ 86 mm
// (Muy cercano a 53.98 x 85.60 mm)

class PDF extends FPDF {
    function Header() {
        // Sin cabecera personalizada
    }
    function Footer() {
        $this->SetY(-5);
        $this->SetFont('Arial','I',6);
        $this->Cell(0,3,utf8_decode('Radio Autlan'),0,0,'C');
    }
}

// Creamos el PDF en orientación "P" (vertical),
// con ancho 53.98 mm y alto 85.60 mm
$pdf = new PDF('P', 'mm', [53.98, 85.60]);
$pdf->AddPage();

// Obtenemos el ancho y alto de la página
$pageWidth  = $pdf->GetPageWidth();   // ~ 53.98 mm
$pageHeight = $pdf->GetPageHeight();  // ~ 85.60 mm

// -----------------------
// 1) LOGO CENTRADO
// -----------------------
$logoWidth = 20;  // Ajusta el ancho del logo según necesites
$logoX = ($pageWidth - $logoWidth) / 2; // Calcula posición X para centrar
$logoY = 5;                             // Un poco de margen superior
$pdf->Image('images/logoradio2.jpg', $logoX, $logoY, $logoWidth);

// Damos un salto vertical debajo del logo
$pdf->SetY($logoY + 20);

// -----------------------
// 2) TÍTULO
// -----------------------
$pdf->SetFont('Arial','B',9);
$pdf->Cell(0,5,utf8_decode('Credencial de Préstamo'),0,1,'C');
$pdf->Ln(2);

// -----------------------
// 3) DATOS DEL SOLICITANTE
// -----------------------
$pdf->SetFont('Arial','',8);
$pdf->Cell(0,4,utf8_decode('Código: ').utf8_decode($solicitante['codigoInstitucion']),0,1,'C');
$pdf->Cell(0,4,utf8_decode('Nombre: ').utf8_decode($solicitante['nombreCompleto']),0,1,'C');
$pdf->Cell(0,4,utf8_decode('Cargo: ').utf8_decode($solicitante['cargo']),0,1,'C');
$pdf->Ln(2);

// -----------------------
// 4) QR CENTRADO
// -----------------------
$qrWidth = 25;  // Ancho del QR dentro del PDF
$qrX = ($pageWidth - $qrWidth) / 2; // Centrar horizontal
$qrY = $pdf->GetY();                // Posición vertical actual
$pdf->Image($tempQRPath, $qrX, $qrY, $qrWidth);

// Eliminamos la imagen temporal
unlink($tempQRPath);

// -----------------------
// MOSTRAR EL PDF EN EL NAVEGADOR
// -----------------------
header("Content-Type: application/pdf");
header("Content-Disposition: inline; filename=credencial_prestamo.pdf");
$pdf->Output('I');
